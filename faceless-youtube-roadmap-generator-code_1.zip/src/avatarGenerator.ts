export interface AvatarBlueprintData {
  experience: string;
  avatarStyle: string;
  avatarPersonality: string;
  riggingSource: string;
  niche: string;
  subNiche: string;
  targetAudience: string;
  topicFormat: string;
  nameStatus: string;
  channelName: string;
  monetization: string[];
  frequency: string;
  focus: string;
  videoStyle: string;
  videoLength: string;
}

function pick<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)];
}

const avatarPrefixes = [
  'Virtual', 'Digital', 'Pixel', 'Neon', 'Aura', 'Byte', 'Nova',
  'Vox', 'Echo', 'Mochi', 'Kuro', 'Shiro', 'Rune', 'Zephyr',
];

const avatarSuffixes = [
  'VTuber', 'Avatar', 'Live', 'Channel', 'Sensei', 'Quest', 'Vision',
  'Stream', 'Pix', 'Tales', 'Realm', 'Project', 'Studio', 'Dot',
];

export function generateAvatarNameSuggestions(
  _niche: string,
  avatarStyle: string,
  avatarPersonality: string
): string[] {
  const personalityAdj: Record<string, string[]> = {
    'Warm & Friendly': ['Cuddly', 'Cozy', 'Sunny', 'Gentle', 'Snug', 'Kind'],
    'Energetic & Loud': ['Blast', 'Turbo', 'Wild', 'Hyper', 'Boom', 'Chaos'],
    'Mysterious & Calm': ['Shadow', 'Whisper', 'Void', 'Misty', 'Enigma', 'Quiet'],
    'Professional & Polished': ['Apex', 'Prime', 'Core', 'Elite', 'Pro', 'Axiom'],
    'Quirky & Funny': ['Goof', 'Noodle', 'Wacky', 'Zany', 'Doodle', 'Bloop'],
  };

  const styleHints: Record<string, string[]> = {
    '2D Anime VTuber': ['Anime', 'Kawaii', 'Manga', 'Doki', 'Chan', 'San'],
    '3D Model VTuber': ['3D', 'Poly', 'Voxel', 'Model', 'Render', 'Spatial'],
    'PNGTuber': ['Png', 'Flat', 'Paper', 'Sticker', 'Pixel', 'Sprite'],
    'AI Generated Presenter': ['Synthetic', 'AI', 'Neural', 'Digital', 'Synth', 'Neuro'],
    'Simple Cartoon / Mascot': ['Toon', 'Cartoon', 'Mascot', 'Doodle', 'Sketch', 'Buddy'],
  };

  const adjs = personalityAdj[avatarPersonality] || ['Cool', 'Neat', 'Fresh'];
  const hints = styleHints[avatarStyle] || ['Virtual', 'Digital'];

  const names = new Set<string>();
  for (let i = 0; i < 8; i++) {
    const prefix = pick(avatarPrefixes);
    const suffix = pick(avatarSuffixes);
    const adj = pick(adjs);
    const hint = pick(hints);

    const patterns = [
      `${adj}${pick(['', ' '])}${prefix}`,
      `${prefix} ${suffix}`,
      `${adj} ${hint}`,
      `${pick([adj, hint])} ${pick(['', 'the '])}${suffix}`,
    ];
    names.add(pick(patterns));
  }

  return Array.from(names).slice(0, 6);
}

export function generateAvatarTechnicalStack(
  experience: string,
  avatarStyle: string
) {
  const baseAvatarTools: Record<string, Record<string, { name: string; use: string }>> = {
    '2D Anime VTuber': {
      beginner: { name: 'Veadotube Mini + PNG Rig', use: 'Free 2D avatar tracking with webcam. No Live2D required.' },
      intermediate: { name: 'Live2D Cubism + VTube Studio', use: 'Full 2D rigging with facial tracking via iPhone or webcam.' },
      advanced: { name: 'Live2D Cubism Pro + VTube Studio + XR Animator', use: 'Complex 2D puppeteering with multi-parameter expressions.' },
    },
    '3D Model VTuber': {
      beginner: { name: 'VRoid Studio + VMagicMirror', use: 'Free 3D anime avatar creation with basic tracking integration.' },
      intermediate: { name: 'VRoid Studio + VSeeFace + Unity', use: 'Custom 3D avatars with full facial/body tracking.' },
      advanced: { name: 'Blender + VSeeFace + Warudo + HTC Vive Trackers', use: 'Full-body 3D tracking with custom-rigged models.' },
    },
    'PNGTuber': {
      beginner: { name: 'PNG Tuber Plus (Steam)', use: 'Free/cheap static image rigging with mouth and eye states.' },
      intermediate: { name: 'PNG Tuber Plus + OBS Docks', use: 'Multi-state PNG animation with expression hotkeys.' },
      advanced: { name: 'Custom Sprites + PNG Tuber Pro + Live2D Cubism Import', use: 'Hybrid PNG-to-3D blendshapes for richer animation.' },
    },
    'AI Generated Presenter': {
      beginner: { name: 'HeyGen / Synthesia Basic', use: 'Text-to-video AI presenter with pre-built avatar templates.' },
      intermediate: { name: 'Synthesia Custom Avatar + ElevenLabs', use: 'AI presenter trained on custom image with voice cloning.' },
      advanced: { name: 'D-ID + SadTalker + Wav2Lip Locally', use: 'Self-hosted AI face animation with full lip-sync control.' },
    },
    'Simple Cartoon / Mascot': {
      beginner: { name: 'Canva Animate + OBS', use: 'Animated mascot sticker imported as a browser source.' },
      intermediate: { name: 'Adobe Character Animator', use: 'Real-time 2D cartoon puppeteering with webcam lip-sync.' },
      advanced: { name: 'Blender Grease Pencil + Spriter Pro', use: 'Custom cartoon rig with bone animation and motion capture.' },
    },
  };

  const levelKey = experience === 'Advanced' ? 'advanced' : experience === 'Intermediate' ? 'intermediate' : 'beginner';
  const styleTools = baseAvatarTools[avatarStyle] || baseAvatarTools['PNGTuber'];
  const avatarTool = styleTools[levelKey];

  const common = (expLvl: string) => {
    if (expLvl === 'Advanced') {
      return {
        script: { name: 'Claude 3.5 Sonnet + ChatGPT', use: 'Avatar-first scriptwriting with character voice and pacing.' },
        voice: { name: 'ElevenLabs Voice Cloning', use: 'Custom voice that matches your avatar personality.' },
        visuals: { name: 'Midjourney / DALL-E 3', use: 'Backgrounds, transitions, and scene assets matching avatar aesthetic.' },
        editing: { name: 'Premiere Pro + After Effects', use: 'Advanced compositing, effects, and avatar overlay integration.' },
        thumbnail: { name: 'Photoshop + Canva Pro', use: 'Avatar-faced thumbnails with strong CTR hooks.' },
      };
    } else if (expLvl === 'Intermediate') {
      return {
        script: { name: 'ChatGPT 4o', use: 'Scripting tailored to your avatar persona and audience.' },
        voice: { name: 'ElevenLabs Standard / Murf AI', use: 'Natural-sounding voice aligned with avatar personality.' },
        visuals: { name: 'Leonardo AI + Pexels', use: 'Custom backgrounds and scene graphics.' },
        editing: { name: 'DaVinci Resolve / CapCut', use: 'Avatar compositing, chroma key, and dynamic captions.' },
        thumbnail: { name: 'Canva Pro + Remove.bg', use: 'Avatar overlay thumbnails with bold text.' },
      };
    } else {
      return {
        script: { name: 'ChatGPT Free / Claude', use: 'Basic topic structuring and bullet-point scripts.' },
        voice: { name: 'ElevenLabs Free / TTSMaker', use: 'Basic AI voice output for avatar lip-sync.' },
        visuals: { name: 'Pexels + Canva Free', use: 'Free stock scenes and simple avatar backdrops.' },
        editing: { name: 'CapCut Desktop/Mobile', use: 'Simple cuts, avatar overlay, and auto-captions.' },
        thumbnail: { name: 'Canva Free Tier', use: 'Pre-made thumbnail templates with avatar placement.' },
      };
    }
  };

  return {
    avatar: avatarTool,
    ...common(experience),
  };
}

export function generateAvatarContentCalendar(frequency: string) {
  const schedules: Record<string, string[]> = {
    'Daily': [
      'Record 30-min avatar test session to check tracking',
      'Produce + upload Short with avatar intro',
      'Batch record 2 main segments',
      'Post-production & export',
    ],
    '1-2 times per week': [
      'Monday: Avatar rigging tweaks + scene prep',
      'Tuesday: Scriptwriting with character voice injection',
      'Wednesday: Avatar recording session (tracking calibration)',
      'Thursday: Audio cleanup + lip-sync pass',
      'Friday: Video editing + thumbnail with avatar face',
      'Saturday: Upload + community post (stay in character)',
      'Sunday: Analytics review + fan interaction',
    ],
    '3-5 times per week': [
      'Mon/Wed/Fri: Upload days with fresh avatar outfits',
      'Tue/Thu: Batch recording + rigging adjustments',
      'Sat/Sun: Asset creation + character lore writing',
    ],
    'Bi-weekly': [
      'Week 1: Avatar redesign/refinement + script deep-dive',
      'Week 2: Full recording + editing + upload with premiere event',
    ],
    'Monthly': [
      'Week 1: Avatar model updates + script',
      'Week 2: Asset creation + voice recording',
      'Week 3: Video editing + thumbnail + SEO',
      'Week 4: Upload + community engagement + debut hype',
    ],
  };
  return schedules[frequency] || schedules['1-2 times per week'];
}

export function generateAvatarFirstVideoScript(data: AvatarBlueprintData) {
  const { niche, subNiche, avatarStyle, avatarPersonality, focus, videoStyle, topicFormat } = data;
  const topicName = subNiche || niche;

  return {
    title: `${avatarStyle} Explains ${topicName}: The Truth You Need to ${pick(['Know', 'Hear', 'See', 'Understand'])}`,
    hook: `0:00 - 0:20 | ${avatarPersonality} avatar appears with a signature gesture. Ask a provocative ${topicName} question while the avatar makes direct eye contact.`,
    intro: `0:20 - 1:30 | Avatar introduces itself with a short character beat ("I'm your host, and here's why ${topicName} matters to YOU"). Tease the ${topicFormat} format ahead.`,
    body: [
      `Point 1: The avatar breaks down the current state of ${topicName} with on-screen visual aids.`,
      `Point 2: Personality-driven ${focus} analysis of the core problem — avatar reacts with expressions.`,
      `Point 3: ${videoStyle} deep dive showing actionable steps, with avatar demonstrating or narrating.`,
      `Point 4: Avatar delivers a passionate call for change in ${niche}, tying back to character values.`,
    ],
    cta: `Wrap-up | Avatar addresses the audience directly: "Like if you agree, subscribe to join the ${avatarStyle} fam, and comment your hot take on ${topicName}."`,
    thumbnailDesc: `Close-up of avatar face with exaggerated expression (shock/excitement). Bold text overlay: "${topicName} IS CHANGING". ${avatarStyle} aesthetic background with neon accents.`,
  };
}

export function generateAvatarFullPrompt(data: AvatarBlueprintData): string {
  return `You are an interactive AI Coach specialized in launching AVATAR-LED (VTuber/PNGTuber/AI Presenter) faceless YouTube channels.
Here is my custom channel criteria:
- Experience Level: ${data.experience}
- Avatar Style: ${data.avatarStyle}
- Avatar Personality: ${data.avatarPersonality}
- Rigging Approach: ${data.riggingSource}
- Niche: ${data.niche}
- Sub-Niche: ${data.subNiche || 'General'}
- Target Audience: ${data.targetAudience}
- Content Format: ${data.topicFormat}
- Channel Name: ${data.channelName || 'Needs suggestions'}
- Monetization: ${data.monetization.join(', ')}
- Upload Frequency: ${data.frequency}
- Channel Focus: ${data.focus}
- Video Style: ${data.videoStyle}
- Video Length: ${data.videoLength}

Based on these details, create a COMPLETE avatar-led YouTube launch roadmap:

1. Character Identity & Branding
   - Design a memorable color palette, visual style, and "character lore" hook for my ${data.avatarStyle} avatar.
   - How to make the ${data.avatarPersonality} personality shine through in every video.
   
2. Avatar Pipeline Setup
   - Recommend the best software stack for my ${data.avatarStyle} avatar style at a ${data.experience} level.
   - Step-by-step rigging workflow (especially for ${data.riggingSource} approach).
   
3. Content Strategy & First Video Script
   - 5 video title ideas combining ${data.avatarStyle} aesthetic with ${data.niche} content.
   - A full script outline where the avatar's ${data.avatarPersonality} personality drives retention.
   
4. Monetization & Community Building
   - How to build a character-driven community (lore, emotes, membership tiers).
   - Specific milestones to reach each of my chosen revenue streams: ${data.monetization.join(', ')}.
   
5. Technical Optimization
   - SEO tips specific to avatar/VTuber channels.
   - Recommended streaming and uploading cadence for ${data.frequency} schedule.

Acknowledge my avatar concept and produce the blueprint step by step.`;
}
