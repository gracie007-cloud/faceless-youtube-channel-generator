import { useState } from 'react';
import confetti from 'canvas-confetti';
import {
  Award,
  Video,
  Settings,
  Calendar,
  Sparkles,
  ArrowRight,
  ArrowLeft,
  CheckCircle,
  Copy,
  Layout,
  DollarSign,
  Tv,
  Target,
  RefreshCw,
  UserCircle2,
  Bot,
  Smile,
  Palette,
} from 'lucide-react';
import {
  AvatarBlueprintData,
  generateAvatarNameSuggestions,
  generateAvatarTechnicalStack,
  generateAvatarContentCalendar,
  generateAvatarFirstVideoScript,
  generateAvatarFullPrompt,
} from './avatarGenerator';

// Initial state for avatar-led questionnaire
const initialData: AvatarBlueprintData = {
  experience: 'Beginner',
  avatarStyle: 'PNGTuber',
  avatarPersonality: 'Warm & Friendly',
  riggingSource: 'I will DIY rig myself',
  niche: 'Education',
  subNiche: '',
  targetAudience: '',
  topicFormat: 'Concept overview',
  nameStatus: 'No, I need name suggestions',
  channelName: '',
  monetization: ['YouTube AdSense'],
  frequency: '1-2 times per week',
  focus: 'Beginner-Friendly',
  videoStyle: 'Educational',
  videoLength: '5-10 minutes',
};

const experienceOptions = ['Beginner', 'Intermediate', 'Advanced'];

const avatarStyleOptions = [
  '2D Anime VTuber',
  '3D Model VTuber',
  'PNGTuber',
  'AI Generated Presenter',
  'Simple Cartoon / Mascot',
];

const personalityOptions = [
  'Warm & Friendly',
  'Energetic & Loud',
  'Mysterious & Calm',
  'Professional & Polished',
  'Quirky & Funny',
];

const riggingOptions = [
  'I will DIY rig myself',
  'Commission a professional rigger',
  'Use a no-rig / auto-rig tool',
  'Not sure yet',
];

const nicheOptions = [
  'Autos & Vehicles',
  'Comedy',
  'Education',
  'Entertainment',
  'Film & Animation',
  'Gaming',
  'How-to & Style',
  'Music',
  'News & Politics',
  'Nonprofits & Activism',
  'People & Blogs',
  'Pets & Animals',
  'Science & Technology',
  'Sports',
  'Travel & Events',
];

const formatOptions = [
  'Activity',
  'Concept overview',
  'How-to',
  'Lecture',
  'Problem walkthrough',
  'Real life application',
  'Science experiment',
  'Tips',
  'Other',
  'Not sure',
];

const focusOptions = [
  'Analysis',
  'Beginner-Friendly',
  'Deep Dives',
  'Psychology and Sentiments',
  'Recap & Quick Briefs',
  'Report Summaries',
  'Sector/Industry Updates',
  'Spotlights',
  'Strategies',
  'Trends',
];

const styleOptions = [
  'Data & Analysis',
  'Documentary Style',
  'Educational',
  'Entertaining',
  'Motivational',
  'News & Commentary',
  'Quick-Tips & Hacks',
  'Reviews & Recommendations',
];

const lengthOptions = [
  'Under 3 minutes (Shorts)',
  '3-5 minutes',
  '5-10 minutes',
  '10-15 minutes',
  '15-20 minutes',
  '20+ minutes',
];

const frequencyOptions = [
  'Daily',
  '1-2 times per week',
  '3-5 times per week',
  'Bi-weekly',
  'Monthly',
];

const monetizationOptions = [
  'YouTube AdSense',
  'Affiliate Marketing',
  'Brand Sponsorships',
  'Channel Memberships',
  'Merchandise',
  'Online Courses',
  'Selling Digital Products',
  'Super Chats & Donations',
  'Custom Emotes / Badges',
];

const totalSteps = 7; // 1 (exp) + 2 (avatar) + 3 (niche) + 4 (format) + 5 (style) + 6 (name/freq/money) + welcome(0)

export default function App() {
  const [step, setStep] = useState<number>(0);
  const [data, setData] = useState<AvatarBlueprintData>(initialData);
  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<string>('overview');
  const [copied, setCopied] = useState<boolean>(false);

  const updateField = (field: keyof AvatarBlueprintData, value: any) => {
    setData((prev) => ({ ...prev, [field]: value }));
  };

  const toggleMonetization = (item: string) => {
    setData((prev) => {
      const exists = prev.monetization.includes(item);
      const updated = exists
        ? prev.monetization.filter((m) => m !== item)
        : [...prev.monetization, item];
      return { ...prev, monetization: updated.length ? updated : ['YouTube AdSense'] };
    });
  };

  const handleNext = () => {
    if (step < totalSteps) {
      setStep((prev) => prev + 1);
    } else {
      triggerGeneration();
    }
  };

  const handleBack = () => {
    if (step > 0) setStep((prev) => prev - 1);
  };

  const triggerGeneration = () => {
    setIsGenerating(true);
    setTimeout(() => {
      setIsGenerating(false);
      setStep(totalSteps + 1); // Dashboard Step = 8
      confetti({
        particleCount: 120,
        spread: 80,
        origin: { y: 0.6 },
      });
    }, 2800);
  };

  const handleCopyPrompt = () => {
    const fullPrompt = generateAvatarFullPrompt(data);
    navigator.clipboard.writeText(fullPrompt);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const restartQuiz = () => {
    setData(initialData);
    setStep(0);
    setActiveTab('overview');
  };

  // Computed Dashboard Values
  const nameSuggestions = generateAvatarNameSuggestions(data.niche, data.avatarStyle, data.avatarPersonality);
  const techStack = generateAvatarTechnicalStack(data.experience, data.avatarStyle);
  const contentCalendar = generateAvatarContentCalendar(data.frequency);
  const scriptOutline = generateAvatarFirstVideoScript(data);

  return (
    <div className="min-h-screen bg-slate-900 text-slate-100 flex flex-col items-center font-sans antialiased">

      {/* Top Navbar */}
      <nav className="w-full border-b border-slate-800 bg-slate-950/60 backdrop-blur-md px-6 py-4 flex items-center justify-between sticky top-0 z-50">
        <div className="flex items-center gap-2 cursor-pointer" onClick={restartQuiz}>
          <div className="bg-gradient-to-br from-purple-600 to-pink-500 p-2 rounded-xl text-white shadow-lg shadow-purple-900/30">
            <Bot className="w-6 h-6" />
          </div>
          <span className="font-bold text-xl tracking-tight text-white">
            Avatar<span className="text-purple-400">Tube</span> Blueprint
          </span>
        </div>
        {step > 0 && step <= totalSteps && (
          <div className="text-sm font-medium text-slate-400 bg-slate-800/40 px-3 py-1 rounded-full border border-slate-700/50">
            Step {step} of {totalSteps}
          </div>
        )}
      </nav>

      <main className="flex-1 w-full max-w-6xl p-6 flex flex-col justify-center items-center">

        {/* STEP 0: Welcome Screen */}
        {step === 0 && (
          <div className="max-w-2xl text-center space-y-8 animate-fade-in">
            <div className="inline-flex p-4 rounded-3xl bg-purple-500/10 text-purple-400 ring-1 ring-purple-500/20 shadow-inner">
              <UserCircle2 className="w-12 h-12" />
            </div>
            <div className="space-y-4">
              <h1 className="text-4xl md:text-5xl font-extrabold tracking-tight text-white leading-tight">
                Build a <span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-400">Avatar-Led YouTube</span> Channel
              </h1>
              <p className="text-slate-400 text-lg md:text-xl">
                Get a complete avatar-driven strategy — from rigging and character design to content scripting and monetization — tailored to your style.
              </p>
            </div>
            <div className="pt-6">
              <button
                onClick={handleNext}
                className="inline-flex items-center gap-3 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-500 hover:to-pink-500 text-white font-semibold text-lg px-8 py-4 rounded-2xl shadow-xl shadow-purple-900/30 hover:shadow-purple-900/40 transform hover:-translate-y-0.5 transition-all"
              >
                Build Your Avatar Strategy <ArrowRight className="w-5 h-5" />
              </button>
            </div>
            <div className="grid grid-cols-3 gap-4 pt-12 border-t border-slate-800 text-slate-400 text-sm">
              <div>
                <div className="font-semibold text-white text-base">3 Minutes</div>
                To Complete
              </div>
              <div>
                <div className="font-semibold text-white text-base">Avatar-Led</div>
                Blueprint Generated
              </div>
              <div>
                <div className="font-semibold text-white text-base">AI Ready</div>
                Prompt Output
              </div>
            </div>
          </div>
        )}

        {/* STEP 1: Experience */}
        {step === 1 && (
          <div className="w-full max-w-xl space-y-6">
            <div className="space-y-2 text-center">
              <h2 className="text-3xl font-bold text-white">Your Experience Level</h2>
              <p className="text-slate-400">What is your current experience with avatar-led / VTuber content creation?</p>
            </div>
            <div className="grid gap-4 mt-6">
              {experienceOptions.map((option) => (
                <button
                  key={option}
                  onClick={() => updateField('experience', option)}
                  className={`flex items-center justify-between p-5 rounded-2xl border font-medium text-left transition-all ${
                    data.experience === option
                      ? 'border-purple-500 bg-purple-500/10 text-white shadow-lg shadow-purple-500/10'
                      : 'border-slate-800 bg-slate-850 hover:bg-slate-800 hover:border-slate-700 text-slate-300'
                  }`}
                >
                  <span className="text-lg">{option}</span>
                  {data.experience === option && <CheckCircle className="w-6 h-6 text-purple-500" />}
                </button>
              ))}
            </div>
            <div className="flex justify-between mt-8">
              <button onClick={handleBack} className="flex items-center gap-2 text-slate-400 hover:text-white font-medium">
                <ArrowLeft className="w-4 h-4" /> Back
              </button>
              <button onClick={handleNext} className="flex items-center gap-2 bg-slate-100 hover:bg-white text-slate-900 font-semibold px-6 py-3 rounded-xl shadow-md transition-all">
                Next <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* STEP 2: Avatar Style & Rigging */}
        {step === 2 && (
          <div className="w-full max-w-2xl space-y-6">
            <div className="space-y-2 text-center">
              <h2 className="text-3xl font-bold text-white">Your Avatar Identity</h2>
              <p className="text-slate-400">Define the look, personality, and approach for your digital presenter.</p>
            </div>
            <div className="grid gap-6 mt-6">
              <div>
                <label className="block text-sm font-semibold text-slate-300 mb-2">Avatar Style</label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {avatarStyleOptions.map((opt) => {
                    const icons: Record<string, React.ReactNode> = {
                      '2D Anime VTuber': <Smile className="w-5 h-5" />,
                      '3D Model VTuber': <UserCircle2 className="w-5 h-5" />,
                      'PNGTuber': <Palette className="w-5 h-5" />,
                      'AI Generated Presenter': <Bot className="w-5 h-5" />,
                      'Simple Cartoon / Mascot': <Sparkles className="w-5 h-5" />,
                    };
                    return (
                      <button
                        key={opt}
                        onClick={() => updateField('avatarStyle', opt)}
                        className={`flex items-center gap-3 p-4 rounded-xl border text-sm font-medium transition-all ${
                          data.avatarStyle === opt
                            ? 'border-purple-500 bg-purple-500/10 text-white'
                            : 'border-slate-800 bg-slate-850 text-slate-400 hover:text-white'
                        }`}
                      >
                        {icons[opt]}
                        <span>{opt}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              <div>
                <label className="block text-sm font-semibold text-slate-300 mb-2">Avatar Personality</label>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                  {personalityOptions.map((opt) => (
                    <button
                      key={opt}
                      onClick={() => updateField('avatarPersonality', opt)}
                      className={`py-2.5 px-3 rounded-lg border text-sm font-medium transition-all ${
                        data.avatarPersonality === opt
                          ? 'border-purple-500 bg-purple-500/10 text-white'
                          : 'border-slate-800 bg-slate-850 text-slate-400 hover:text-white'
                      }`}
                    >
                      {opt}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-sm font-semibold text-slate-300 mb-2">Rigging Approach</label>
                <div className="grid gap-2">
                  {riggingOptions.map((opt) => (
                    <button
                      key={opt}
                      onClick={() => updateField('riggingSource', opt)}
                      className={`flex items-center justify-between p-3 rounded-xl border text-sm font-medium transition-all ${
                        data.riggingSource === opt
                          ? 'border-purple-500 bg-purple-500/10 text-white'
                          : 'border-slate-800 bg-slate-850 text-slate-400 hover:text-white'
                      }`}
                    >
                      <span>{opt}</span>
                      {data.riggingSource === opt && <CheckCircle className="w-4 h-4 text-purple-500" />}
                    </button>
                  ))}
                </div>
              </div>
            </div>
            <div className="flex justify-between mt-8">
              <button onClick={handleBack} className="flex items-center gap-2 text-slate-400 hover:text-white font-medium">
                <ArrowLeft className="w-4 h-4" /> Back
              </button>
              <button onClick={handleNext} className="flex items-center gap-2 bg-slate-100 hover:bg-white text-slate-900 font-semibold px-6 py-3 rounded-xl shadow-md transition-all">
                Next <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* STEP 3: Niche & Audience */}
        {step === 3 && (
          <div className="w-full max-w-2xl space-y-6">
            <div className="space-y-2 text-center">
              <h2 className="text-3xl font-bold text-white">Niche & Target Audience</h2>
              <p className="text-slate-400">Pick the niche your avatar will explore and entertain.</p>
            </div>
            <div className="grid gap-6 mt-6">
              <div>
                <label className="block text-sm font-semibold text-slate-300 mb-2">Select Your Core Niche</label>
                <select
                  value={data.niche}
                  onChange={(e) => updateField('niche', e.target.value)}
                  className="w-full bg-slate-850 border border-slate-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-purple-500 focus:ring-1 focus:ring-purple-500"
                >
                  {nicheOptions.map((niche) => (
                    <option key={niche} value={niche}>{niche}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-semibold text-slate-300 mb-2">Sub-Niche (Optional but Recommended)</label>
                <input
                  type="text"
                  placeholder="e.g. Retro Gaming, Stoic Philosophy, Tech Gadgets"
                  value={data.subNiche}
                  onChange={(e) => updateField('subNiche', e.target.value)}
                  className="w-full bg-slate-850 border border-slate-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-purple-500 focus:ring-1 focus:ring-purple-500"
                />
              </div>
              <div>
                <label className="block text-sm font-semibold text-slate-300 mb-2">Target Audience (Who is watching your avatar?)</label>
                <input
                  type="text"
                  placeholder="e.g. Gen Z gamers, Anime fans, Aspiring entrepreneurs"
                  value={data.targetAudience}
                  onChange={(e) => updateField('targetAudience', e.target.value)}
                  className="w-full bg-slate-850 border border-slate-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-purple-500 focus:ring-1 focus:ring-purple-500"
                />
              </div>
            </div>
            <div className="flex justify-between mt-8">
              <button onClick={handleBack} className="flex items-center gap-2 text-slate-400 hover:text-white font-medium">
                <ArrowLeft className="w-4 h-4" /> Back
              </button>
              <button onClick={handleNext} className="flex items-center gap-2 bg-slate-100 hover:bg-white text-slate-900 font-semibold px-6 py-3 rounded-xl shadow-md transition-all">
                Next <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* STEP 4: Format & Channel Focus */}
        {step === 4 && (
          <div className="w-full max-w-2xl space-y-6">
            <div className="space-y-2 text-center">
              <h2 className="text-3xl font-bold text-white">Avatar Content Style</h2>
              <p className="text-slate-400">Decide the narrative angle for your avatar's content.</p>
            </div>
            <div className="grid gap-6 mt-6">
              <div>
                <label className="block text-sm font-semibold text-slate-300 mb-2">Format of Your Videos</label>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                  {formatOptions.map((opt) => (
                    <button
                      key={opt}
                      onClick={() => updateField('topicFormat', opt)}
                      className={`py-2 px-3 rounded-lg border text-sm font-medium transition-all ${
                        data.topicFormat === opt
                          ? 'border-purple-500 bg-purple-500/10 text-white'
                          : 'border-slate-800 bg-slate-850 text-slate-400 hover:text-white'
                      }`}
                    >
                      {opt}
                    </button>
                  ))}
                </div>
              </div>
              <div>
                <label className="block text-sm font-semibold text-slate-300 mb-2">Primary Channel Focus</label>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                  {focusOptions.map((opt) => (
                    <button
                      key={opt}
                      onClick={() => updateField('focus', opt)}
                      className={`py-2 px-3 rounded-lg border text-sm font-medium transition-all ${
                        data.focus === opt
                          ? 'border-purple-500 bg-purple-500/10 text-white'
                          : 'border-slate-800 bg-slate-850 text-slate-400 hover:text-white'
                      }`}
                    >
                      {opt}
                    </button>
                  ))}
                </div>
              </div>
            </div>
            <div className="flex justify-between mt-8">
              <button onClick={handleBack} className="flex items-center gap-2 text-slate-400 hover:text-white font-medium">
                <ArrowLeft className="w-4 h-4" /> Back
              </button>
              <button onClick={handleNext} className="flex items-center gap-2 bg-slate-100 hover:bg-white text-slate-900 font-semibold px-6 py-3 rounded-xl shadow-md transition-all">
                Next <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* STEP 5: Video Style & Length */}
        {step === 5 && (
          <div className="w-full max-w-2xl space-y-6">
            <div className="space-y-2 text-center">
              <h2 className="text-3xl font-bold text-white">Avatar Presentation & Duration</h2>
              <p className="text-slate-400">How your avatar delivers content and for how long.</p>
            </div>
            <div className="grid gap-6 mt-6">
              <div>
                <label className="block text-sm font-semibold text-slate-300 mb-2">Video Style (Tone & Format)</label>
                <div className="grid grid-cols-2 gap-3">
                  {styleOptions.map((opt) => (
                    <button
                      key={opt}
                      onClick={() => updateField('videoStyle', opt)}
                      className={`p-3 rounded-xl border text-sm text-left font-medium transition-all ${
                        data.videoStyle === opt
                          ? 'border-purple-500 bg-purple-500/10 text-white'
                          : 'border-slate-800 bg-slate-850 text-slate-400 hover:text-white'
                      }`}
                    >
                      {opt}
                    </button>
                  ))}
                </div>
              </div>
              <div>
                <label className="block text-sm font-semibold text-slate-300 mb-2">Average Video Length</label>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                  {lengthOptions.map((opt) => (
                    <button
                      key={opt}
                      onClick={() => updateField('videoLength', opt)}
                      className={`py-2 px-3 rounded-lg border text-sm font-medium transition-all ${
                        data.videoLength === opt
                          ? 'border-purple-500 bg-purple-500/10 text-white'
                          : 'border-slate-800 bg-slate-850 text-slate-400 hover:text-white'
                      }`}
                    >
                      {opt}
                    </button>
                  ))}
                </div>
              </div>
            </div>
            <div className="flex justify-between mt-8">
              <button onClick={handleBack} className="flex items-center gap-2 text-slate-400 hover:text-white font-medium">
                <ArrowLeft className="w-4 h-4" /> Back
              </button>
              <button onClick={handleNext} className="flex items-center gap-2 bg-slate-100 hover:bg-white text-slate-900 font-semibold px-6 py-3 rounded-xl shadow-md transition-all">
                Next <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* STEP 6: Name, Frequency & Monetization */}
        {step === 6 && (
          <div className="w-full max-w-2xl space-y-6">
            <div className="space-y-2 text-center">
              <h2 className="text-3xl font-bold text-white">Brand, Cadence & Revenue</h2>
              <p className="text-slate-400">Name your avatar channel and plan your monetization.</p>
            </div>
            <div className="grid gap-6 mt-6">
              <div>
                <label className="block text-sm font-semibold text-slate-300 mb-2">Channel Name</label>
                <div className="grid grid-cols-2 gap-3 mb-3">
                  {['Yes, I already have a name', 'No, I need name suggestions'].map((opt) => (
                    <button
                      key={opt}
                      onClick={() => updateField('nameStatus', opt)}
                      className={`p-3 rounded-xl border text-sm font-medium transition-all ${
                        data.nameStatus === opt
                          ? 'border-purple-500 bg-purple-500/10 text-white'
                          : 'border-slate-800 bg-slate-850 text-slate-400 hover:text-white'
                      }`}
                    >
                      {opt}
                    </button>
                  ))}
                </div>
                {data.nameStatus.startsWith('Yes') && (
                  <input
                    type="text"
                    placeholder="Enter your avatar channel name"
                    value={data.channelName}
                    onChange={(e) => updateField('channelName', e.target.value)}
                    className="w-full bg-slate-850 border border-slate-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-purple-500 focus:ring-1 focus:ring-purple-500"
                  />
                )}
              </div>

              <div>
                <label className="block text-sm font-semibold text-slate-300 mb-2">Upload Frequency</label>
                <select
                  value={data.frequency}
                  onChange={(e) => updateField('frequency', e.target.value)}
                  className="w-full bg-slate-850 border border-slate-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-purple-500 focus:ring-1 focus:ring-purple-500"
                >
                  {frequencyOptions.map((freq) => (
                    <option key={freq} value={freq}>{freq}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-semibold text-slate-300 mb-2">Monetization (select all that apply)</label>
                <div className="grid gap-2 sm:grid-cols-2">
                  {monetizationOptions.map((opt) => {
                    const selected = data.monetization.includes(opt);
                    return (
                      <button
                        key={opt}
                        onClick={() => toggleMonetization(opt)}
                        className={`flex items-center justify-between p-3 rounded-xl border text-sm font-medium transition-all ${
                          selected
                            ? 'border-purple-500 bg-purple-500/10 text-white'
                            : 'border-slate-800 bg-slate-850 text-slate-400 hover:bg-slate-800'
                        }`}
                      >
                        <span>{opt}</span>
                        <span className={`w-5 h-5 rounded-md border flex items-center justify-center transition-all ${
                          selected ? 'bg-purple-500 border-purple-500 text-white' : 'border-slate-700 bg-slate-900'
                        }`}>
                          {selected && <CheckCircle className="w-4 h-4" />}
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
            <div className="flex justify-between mt-8">
              <button onClick={handleBack} className="flex items-center gap-2 text-slate-400 hover:text-white font-medium">
                <ArrowLeft className="w-4 h-4" /> Back
              </button>
              <button
                onClick={handleNext}
                className="flex items-center gap-2 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-500 hover:to-pink-500 text-white font-semibold px-8 py-3 rounded-xl shadow-lg transition-all"
              >
                Generate Avatar Blueprint <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* LOADING ANIMATION */}
        {isGenerating && (
          <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-md z-50 flex flex-col items-center justify-center space-y-6">
            <div className="relative flex items-center justify-center">
              <RefreshCw className="w-16 h-16 text-purple-500 animate-spin" />
              <Bot className="w-6 h-6 text-white absolute" />
            </div>
            <div className="text-center space-y-2">
              <h3 className="text-2xl font-bold text-white">Rigging Your Avatar Blueprint...</h3>
              <p className="text-slate-400 max-w-sm">Combining {data.avatarStyle} with {data.niche} content strategy.</p>
            </div>
            <div className="w-64 h-2 bg-slate-800 rounded-full overflow-hidden">
              <div className="h-full bg-gradient-to-r from-purple-500 to-pink-500 animate-loading-bar"></div>
            </div>
          </div>
        )}

        {/* STEP 7 (actually 8): Blueprint Dashboard */}
        {step === 8 && (
          <div className="w-full grid grid-cols-1 md:grid-cols-4 gap-6 animate-fade-in mt-2 items-start">

            {/* Sidebar navigation */}
            <div className="md:col-span-1 space-y-2">
              <button
                onClick={() => setActiveTab('overview')}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-semibold transition-all ${
                  activeTab === 'overview'
                    ? 'bg-purple-600 text-white shadow-lg shadow-purple-500/20'
                    : 'bg-slate-850 hover:bg-slate-800 text-slate-400'
                }`}
              >
                <Layout className="w-4 h-4" /> Overview
              </button>
              <button
                onClick={() => setActiveTab('tools')}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-semibold transition-all ${
                  activeTab === 'tools'
                    ? 'bg-purple-600 text-white shadow-lg shadow-purple-500/20'
                    : 'bg-slate-850 hover:bg-slate-800 text-slate-400'
                }`}
              >
                <Settings className="w-4 h-4" /> Avatar Stack
              </button>
              <button
                onClick={() => setActiveTab('calendar')}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-semibold transition-all ${
                  activeTab === 'calendar'
                    ? 'bg-purple-600 text-white shadow-lg shadow-purple-500/20'
                    : 'bg-slate-850 hover:bg-slate-800 text-slate-400'
                }`}
              >
                <Calendar className="w-4 h-4" /> Pipeline
              </button>
              <button
                onClick={() => setActiveTab('script')}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-semibold transition-all ${
                  activeTab === 'script'
                    ? 'bg-purple-600 text-white shadow-lg shadow-purple-500/20'
                    : 'bg-slate-850 hover:bg-slate-800 text-slate-400'
                }`}
              >
                <Video className="w-4 h-4" /> Debut Video
              </button>
              <button
                onClick={() => setActiveTab('prompt')}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-semibold transition-all ${
                  activeTab === 'prompt'
                    ? 'bg-purple-600 text-white shadow-lg shadow-purple-500/20'
                    : 'bg-slate-850 hover:bg-slate-800 text-slate-400'
                }`}
              >
                <Sparkles className="w-4 h-4" /> AI Prompt
              </button>

              <div className="pt-6 border-t border-slate-800">
                <button
                  onClick={restartQuiz}
                  className="w-full flex items-center justify-center gap-2 text-sm font-medium text-slate-400 hover:text-white bg-slate-850/40 hover:bg-slate-850 p-3 rounded-xl border border-slate-800 transition-all"
                >
                  <RefreshCw className="w-4 h-4" /> Redo Blueprint
                </button>
              </div>
            </div>

            {/* Main Workspace Display */}
            <div className="md:col-span-3 bg-slate-850/60 backdrop-blur-md rounded-2xl border border-slate-800 p-6 md:p-8 min-h-[400px]">

              {/* TAB: Overview */}
              {activeTab === 'overview' && (
                <div className="space-y-6">
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
                    <div>
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="text-xs font-bold uppercase tracking-wider text-purple-400 bg-purple-500/10 px-2.5 py-1 rounded-md">
                          {data.avatarStyle}
                        </span>
                        <span className="text-xs font-bold uppercase tracking-wider text-pink-400 bg-pink-500/10 px-2.5 py-1 rounded-md">
                          {data.niche}
                        </span>
                      </div>
                      <h3 className="text-3xl font-extrabold text-white mt-2">
                        {data.channelName || (nameSuggestions[0] + ' (Suggested)')}
                      </h3>
                    </div>
                    <button
                      onClick={() => setActiveTab('prompt')}
                      className="flex items-center gap-2 bg-slate-800 hover:bg-slate-700 text-slate-100 text-sm font-medium px-4 py-2 rounded-xl border border-slate-700"
                    >
                      Export to AI Coach
                    </button>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 flex items-center gap-3">
                      <UserCircle2 className="w-6 h-6 text-purple-400" />
                      <div>
                        <p className="text-xs text-slate-500">Avatar Personality</p>
                        <p className="text-sm font-semibold text-white">{data.avatarPersonality}</p>
                      </div>
                    </div>
                    <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 flex items-center gap-3">
                      <Target className="w-6 h-6 text-purple-400" />
                      <div>
                        <p className="text-xs text-slate-500">Target Audience</p>
                        <p className="text-sm font-semibold text-white truncate max-w-[150px]">
                          {data.targetAudience || 'General Enthusiasts'}
                        </p>
                      </div>
                    </div>
                    <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 flex items-center gap-3">
                      <DollarSign className="w-6 h-6 text-purple-400" />
                      <div>
                        <p className="text-xs text-slate-500">Primary Revenue</p>
                        <p className="text-sm font-semibold text-white">{data.monetization[0]}</p>
                      </div>
                    </div>
                  </div>

                  {data.nameStatus.includes('need') && (
                    <div className="space-y-2 mt-4">
                      <h4 className="text-base font-semibold text-slate-200 flex items-center gap-2">
                        <Award className="w-4 h-4 text-purple-400" /> Suggested Avatar Channel Names
                      </h4>
                      <div className="flex flex-wrap gap-2">
                        {nameSuggestions.map((name) => (
                          <span key={name} className="px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-sm text-slate-300 font-medium">
                            {name}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}

                  <div className="space-y-3 mt-4">
                    <h4 className="text-base font-semibold text-slate-200">Avatar-Led Execution Strategy</h4>
                    <p className="text-slate-400 leading-relaxed text-sm">
                      Launching a <strong>{data.avatarStyle}</strong> avatar channel in the <strong>{data.niche}</strong> niche with a <strong>{data.avatarPersonality}</strong> personality. Your avatar delivers content via <strong>{data.videoStyle}</strong> methodologies on a <strong>{data.frequency}</strong> cadence. Focus on character-driven retention mechanics: consistent avatar expressions, voice-lore alignment, and community in-character interaction.
                    </p>
                  </div>
                </div>
              )}

              {/* TAB: Tool Stack */}
              {activeTab === 'tools' && (
                <div className="space-y-6">
                  <div>
                    <h3 className="text-2xl font-bold text-white mb-1">Avatar Tech Stack</h3>
                    <p className="text-slate-400 text-sm">Tools for your <span className="text-purple-400 font-bold">{data.avatarStyle}</span> pipeline at <span className="text-pink-400 font-bold">{data.experience}</span> level.</p>
                  </div>

                  <div className="grid gap-4 mt-4">
                    {Object.entries(techStack).map(([category, details]: [string, any]) => (
                      <div key={category} className="p-4 rounded-xl bg-slate-900 border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                        <div className="space-y-1">
                          <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
                            {category === 'avatar' ? '🎭 Avatar Rigging' :
                             category === 'script' ? '📝 AI Scriptwriting' :
                             category === 'voice' ? '🎙️ Voiceover' :
                             category === 'visuals' ? '🎨 Scenes & Assets' :
                             category === 'editing' ? '✂️ Video Editing' : '🖼️ Thumbnails'}
                          </span>
                          <h4 className="text-lg font-bold text-white">{details.name}</h4>
                          <p className="text-sm text-slate-400">{details.use}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* TAB: Calendar */}
              {activeTab === 'calendar' && (
                <div className="space-y-6">
                  <div>
                    <h3 className="text-2xl font-bold text-white mb-1">Avatar Content Pipeline</h3>
                    <p className="text-slate-400 text-sm">Weekly schedule for <strong>{data.frequency}</strong> uploads.</p>
                  </div>

                  <div className="relative border-l-2 border-purple-500/30 pl-6 ml-4 space-y-6 mt-4">
                    {contentCalendar.map((stepDesc, idx) => (
                      <div key={idx} className="relative">
                        <div className="absolute -left-[33px] bg-gradient-to-br from-purple-600 to-pink-500 rounded-full h-5 w-5 flex items-center justify-center text-xs font-bold text-white border-4 border-slate-900 shadow">
                          {idx + 1}
                        </div>
                        <p className="text-slate-200 text-base font-semibold">{stepDesc}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* TAB: Script */}
              {activeTab === 'script' && (
                <div className="space-y-6">
                  <div className="pb-4 border-b border-slate-800">
                    <h3 className="text-2xl font-bold text-white mb-1">Debut Video Outline</h3>
                    <p className="text-sm text-slate-400">Your avatar's first appearance script blueprint.</p>
                  </div>

                  <div className="space-y-4 text-sm mt-4">
                    <div>
                      <span className="text-xs font-bold text-slate-500 uppercase">Recommended Title</span>
                      <p className="text-lg font-extrabold text-purple-400 mt-1">"{scriptOutline.title}"</p>
                    </div>

                    <div className="p-3 bg-slate-900/60 rounded-xl border border-slate-800">
                      <span className="font-bold text-slate-200 text-xs uppercase flex items-center gap-1">
                        <Tv className="w-3 h-3 text-purple-400" /> Avatar Hook Strategy
                      </span>
                      <p className="text-slate-400 mt-1">{scriptOutline.hook}</p>
                    </div>

                    <div className="p-3 bg-slate-900/60 rounded-xl border border-slate-800">
                      <span className="font-bold text-slate-200 text-xs uppercase flex items-center gap-1">
                        <Tv className="w-3 h-3 text-purple-400" /> Character Introduction
                      </span>
                      <p className="text-slate-400 mt-1">{scriptOutline.intro}</p>
                    </div>

                    <div className="p-3 bg-slate-900/60 rounded-xl border border-slate-800">
                      <span className="font-bold text-slate-200 text-xs uppercase flex items-center gap-1 mb-2">
                        <Tv className="w-3 h-3 text-purple-400" /> Script Body Points
                      </span>
                      <ul className="space-y-2 list-disc list-inside text-slate-400 pl-1">
                        {scriptOutline.body.map((pt, idx) => (
                          <li key={idx}>{pt}</li>
                        ))}
                      </ul>
                    </div>

                    <div className="p-3 bg-slate-900/60 rounded-xl border border-slate-800">
                      <span className="font-bold text-slate-200 text-xs uppercase flex items-center gap-1">
                        <Tv className="w-3 h-3 text-purple-400" /> Avatar CTA
                      </span>
                      <p className="text-slate-400 mt-1">{scriptOutline.cta}</p>
                    </div>

                    <div>
                      <span className="text-xs font-bold text-slate-500 uppercase">Thumbnail Concept</span>
                      <p className="text-slate-300 mt-1 italic">"{scriptOutline.thumbnailDesc}"</p>
                    </div>
                  </div>
                </div>
              )}

              {/* TAB: NotebookLM Prompt */}
              {activeTab === 'prompt' && (
                <div className="space-y-6">
                  <div>
                    <h3 className="text-2xl font-bold text-white mb-1">AI Coach Prompt</h3>
                    <p className="text-slate-400 text-sm">Full avatar-led blueprint to paste into NotebookLM, ChatGPT, or Claude.</p>
                  </div>

                  <div className="bg-slate-950 p-4 border border-slate-800 rounded-xl relative">
                    <pre className="text-slate-300 text-xs md:text-sm font-mono whitespace-pre-wrap leading-relaxed max-h-[300px] overflow-y-auto pr-8">
                      {generateAvatarFullPrompt(data)}
                    </pre>
                  </div>

                  <div className="space-y-4">
                    <div className="bg-slate-900 rounded-xl p-4 border border-slate-800 space-y-2 text-sm text-slate-400">
                      <h4 className="text-white font-bold text-base">How to use it:</h4>
                      <ol className="list-decimal pl-4 space-y-1">
                        <li>Click <span className="font-bold text-white">"Copy Full Prompt"</span> below.</li>
                        <li>Open a new Notebook/Source in <span className="text-white">NotebookLM</span> or <span className="text-white">ChatGPT</span>.</li>
                        <li>Paste and hit Enter to generate your avatar-led content ecosystem.</li>
                      </ol>
                    </div>

                    <button
                      onClick={handleCopyPrompt}
                      className="w-full flex items-center justify-center gap-2 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-500 hover:to-pink-500 text-white font-semibold py-4 rounded-xl shadow-lg transition-all"
                    >
                      {copied ? <CheckCircle className="w-5 h-5" /> : <Copy className="w-5 h-5" />}
                      {copied ? 'Copied to Clipboard!' : 'Copy Full Prompt'}
                    </button>
                  </div>
                </div>
              )}

            </div>
          </div>
        )}

      </main>

      <footer className="w-full text-center py-4 text-xs text-slate-600 border-t border-slate-800 mt-8">
        Avatar-Led Faceless YouTube Channel Blueprint Studio.
      </footer>
    </div>
  );
}
