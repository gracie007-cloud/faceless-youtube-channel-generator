# Codex CLI Semi-Automated Sequence

Run from the cloned repo root.

```bash
codex "Inspect this repo and summarize the app variants, stack, and missing production features. Write findings to docs/repo-assessment.md."

codex "Make the React/Vite implementation production-buildable. Do not change product behavior. Run npm ci and npm run build; fix any TypeScript or bundling errors."

codex "Add draft persistence with localStorage, inline validation errors, focus management between wizard steps, and a 'not sure' recommendation helper. Keep changes small and testable."

codex "Replace NotebookLM-first guidance in the generated output panel with Claude, ChatGPT, and Gemini destinations plus a warning that NotebookLM and Perplexity are not prompt-execution tools."

codex "Add Cloud Run deployment files: Dockerfile, nginx.conf, .dockerignore, cloudbuild.yaml, and README instructions. Run docker build if Docker is available; otherwise document the exact command."

codex "Create deploy/hostinger/HOSTINGER_HORIZONS_BUILD_PROMPT.md for the external SaaS variant and deploy/poe/POE_CANVAS_BUILD_PROMPT.md plus deploy/poe/POE_SCRIPT_BOT_SYSTEM_PROMPT.md for the Poe Canvas variant."
```
