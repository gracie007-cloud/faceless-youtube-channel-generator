# Codex Agent Task Pack

Use these as separate parallel tasks in the cloud Codex ecosystem.

## Task 1 — Repo assessment and canonical app selection
Clone https://github.com/gracie007-cloud/faceless-youtube-channel-generator. Inspect README, algorithm-aligned, avatar-led-faceless-variant, code, html-code, and model-responses. Identify the strongest canonical implementation. Report gaps and choose the base app for productionization.

Success criteria:
- Creates `docs/repo-assessment.md`
- Lists variants and trade-offs
- Recommends one canonical base

## Task 2 — External SaaS Hostinger Horizons spec
Create `deploy/hostinger/HOSTINGER_HORIZONS_BUILD_PROMPT.md` and `deploy/hostinger/saas-copy.md` for a public SaaS version.

Success criteria:
- Includes landing, pricing, dashboard, saved blueprints
- Replaces NotebookLM-first guidance with Claude / ChatGPT / Gemini guidance
- Maps Custom GPT as the create-type companion

## Task 3 — Internal Cloud Run package
Containerize the React/Vite app for Google Cloud Run.

Success criteria:
- Adds `Dockerfile`, `.dockerignore`, `nginx.conf`, `cloudbuild.yaml`
- `npm ci` succeeds
- `npm run build` succeeds
- Docker build succeeds
- Cloud Run deploy command is documented
- No API keys in frontend

## Task 4 — Poe Canvas app and Script Bot
Create a compact Poe Canvas version and a paired Script Bot prompt.

Success criteria:
- Adds `deploy/poe/POE_CANVAS_BUILD_PROMPT.md`
- Adds `deploy/poe/POE_SCRIPT_BOT_SYSTEM_PROMPT.md`
- Uses a 3-phase wizard
- Supports inline model execution conceptually through Poe Script Bot

## Task 5 — Shared UX fixes
Patch the app for cross-context baseline improvements.

Success criteria:
- Adds localStorage draft persistence
- Adds keyboard/focus handling to wizard controls
- Adds inline validation errors
- Adds a lightweight `Not sure` recommendation helper
- Updates output panel away from NotebookLM-first guidance
