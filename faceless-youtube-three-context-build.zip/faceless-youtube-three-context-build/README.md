# Faceless YouTube Generator — Three Context Build Bundle

This bundle contains three deployment-ready expressions of the same product concept:

1. `01-hostinger-horizons-external` — External SaaS / Hostinger Horizons prompt and static fallback.
2. `02-cloud-run-internal` — React/Vite app packaged for Google Cloud Run.
3. `03-poe-canvas-app` — Poe Canvas single-file prototype plus Poe Script Bot prompt.
4. `04-codex-prompts` — Codex Agent and Codex CLI task sequences.

The static app is frontend-only. It compiles user wizard inputs into structured YouTube channel blueprint outputs and prompt blocks. For production, add persistence/auth/LLM execution in the platform layer appropriate to each context.

## Verified locally
- `npm ci`: completed in the base extracted app.
- `npm run build`: completed successfully and emitted a single-file `dist/index.html`.

## Recommended sequencing
1. Poe Canvas first for fast validation and native LLM handoff.
2. Hostinger Horizons next for public SaaS commercialization.
3. Cloud Run only when internal governance, SSO, audit trails, or agency workflows justify the engineering overhead.
