# External SaaS Variant — Hostinger Horizons

Use `HOSTINGER_HORIZONS_BUILD_PROMPT.md` in Horizons to rebuild the app natively as a public SaaS. `index.html` is a static single-file fallback prototype exported from the React/Vite implementation.

Recommended create type pairing: **Custom GPT** as the public AI companion, connected later via Actions API to the SaaS backend.
