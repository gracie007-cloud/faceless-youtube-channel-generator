# Hostinger Horizons Build Prompt — External SaaS Variant

Build a public SaaS web app called **Faceless YouTube Blueprint Generator**.

The app helps aspiring faceless YouTube creators generate a structured channel launch blueprint from a guided wizard.

## Product flow
1. Landing page with clear value proposition, social-proof style cards, pricing, FAQ, and primary CTA.
2. Signup/login flow with mocked account state unless Horizons native auth is available.
3. 3–5 question onboarding: creator experience, niche, channel goal, monetization preference, upload cadence.
4. Dashboard with a saved blueprint library.
5. Main generator wizard that collects:
   - Experience level
   - Niche
   - Channel idea / topic format
   - Channel name status
   - Monetization model
   - Upload frequency
   - Channel focus
   - Video style
   - Average video length
6. Generated output panel with:
   - Copy full prompt
   - Save blueprint
   - Export text
   - Open in Claude / ChatGPT / Gemini buttons

## Important UX correction
Do **not** position NotebookLM as the default execution target. The post-generation panel should recommend Claude, ChatGPT, and Gemini first. Include a warning that NotebookLM and Perplexity are source/retrieval tools and are not ideal for executing long directive prompts.

## SaaS features
- Free tier: 1 saved blueprint, copy/export enabled.
- Creator tier: unlimited blueprints, additional variants, saved history.
- Studio tier: team workspace, shared blueprint links, audit/export options.

## Design
Modern creator-economy SaaS. Card-based, clean, high contrast, polished but not overcomplicated. Mobile responsive. Use friendly helper copy for non-technical users.

## Technical behavior
Frontend must collect user input, validate wizard steps, generate structured text, and store progress where Horizons supports persistence. No frontend API keys.
