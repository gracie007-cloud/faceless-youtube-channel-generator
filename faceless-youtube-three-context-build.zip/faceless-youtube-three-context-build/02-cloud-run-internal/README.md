# Internal Web App Variant — Google Cloud Run

This is the production-style React/Vite implementation packaged for Cloud Run.

## Local run
```bash
npm ci
npm run dev
```

## Local production build
```bash
npm run build
npm run preview
```

## Docker run
```bash
docker build -t faceless-youtube-generator .
docker run --rm -p 8080:8080 faceless-youtube-generator
```

## Cloud Run deploy
```bash
gcloud builds submit --config cloudbuild.yaml \
  --substitutions=_REGION=us-central1,_REPOSITORY=webapps
```

Recommended access posture: Cloud Run behind IAP / Google Workspace SSO. Add Firestore or Cloud SQL when draft persistence, team libraries, and audit trails are required.

Recommended create type pairing: **Gemini Gem** for internal prompt execution and Google Drive/Docs handoff.
