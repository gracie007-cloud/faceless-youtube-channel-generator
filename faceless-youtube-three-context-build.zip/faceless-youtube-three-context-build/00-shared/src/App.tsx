import { useState } from 'react';
import confetti from 'canvas-confetti';
import {
  Award,
  Video,
  Settings,
  Calendar,
  Sparkles,
  ArrowRight,
  ArrowLeft,
  CheckCircle,
  Copy,
  Layout,
  Clock,
  DollarSign,
  Tv,
  Target,
  RefreshCw,
  User,
} from 'lucide-react';
import {
  BlueprintData,
  generateNameSuggestions,
  generateTechnicalStack,
  generateContentCalendar,
  generateFirstVideoScript,
  generateFullPrompt,
} from './generator';
import {
  AvatarBlueprintData,
  generateNameSuggestions as generateAvatarNames,
  generateAvatarToolStack,
  generateFirstVideoScript as generateAvatarVideoScript,
  generateContentCalendar as generateAvatarCalendar,
  generateFullPrompt as generateAvatarFullPrompt,
} from './avatarGenerator';

// Types & Options setup
const initialStandardData: BlueprintData = {
  experience: 'Beginner',
  niche: 'Education',
  subNiche: '',
  targetAudience: '',
  topicFormat: 'Concept overview',
  nameStatus: 'No, I need name suggestions',
  channelName: '',
  monetization: ['YouTube AdSense'],
  frequency: '1-2 times per week',
  focus: 'Beginner-Friendly',
  videoStyle: 'Educational',
  videoLength: '5-10 minutes',
};

const initialAvatarData: AvatarBlueprintData = {
  experience: 'Beginner',
  niche: 'Gaming',
  subNiche: '',
  targetAudience: '',
  topicFormat: 'Tips',
  nameStatus: 'No, I need name suggestions',
  channelName: '',
  monetization: ['YouTube AdSense'],
  frequency: '1-2 times per week',
  focus: 'Trends',
  videoStyle: 'Entertaining',
  videoLength: '5-10 minutes',
  avatarType: '2D VTuber',
  riggingLevel: 'Advanced (Direct Face Tracking)',
  expressionStyle: 'Highly Animated & Emotive',
};

const experienceOptions = ['Beginner', 'Intermediate', 'Advanced'];

const nicheOptions = [
  'Autos & Vehicles',
  'Comedy',
  'Education',
  'Entertainment',
  'Film & Animation',
  'Gaming',
  'How-to & Style',
  'Music',
  'News & Politics',
  'Nonprofits & Activism',
  'People & Blogs',
  'Pets & Animals',
  'Science & Technology',
  'Sports',
  'Travel & Events',
];

const formatOptions = [
  'Activity',
  'Concept overview',
  'How-to',
  'Lecture',
  'Problem walkthrough',
  'Real life application',
  'Science experiment',
  'Tips',
  'Other',
  'Not sure',
];

const focusOptions = [
  'Analysis',
  'Beginner-Friendly',
  'Deep Dives',
  'Psychology and Sentiments',
  'Recap & Quick Briefs',
  'Report Summaries',
  'Sector/Industry Updates',
  'Spotlights',
  'Strategies',
  'Trends',
];

const styleOptions = [
  'Data & Analysis',
  'Documentary Style',
  'Educational',
  'Entertaining',
  'Motivational',
  'News & Commentary',
  'Quick-Tips & Hacks',
  'Reviews & Recommendations',
];

const lengthOptions = [
  'Under 3 minutes (Shorts)',
  '3-5 minutes',
  '5-10 minutes',
  '10-15 minutes',
  '15-20 minutes',
  '20+ minutes',
];

const frequencyOptions = [
  'Daily',
  '1-2 times per week',
  '3-5 times per week',
  'Bi-weekly',
  'Monthly',
];

const monetizationOptions = [
  'YouTube AdSense',
  'Affiliate Marketing',
  'Brand Sponsorships',
  'Channel Memberships',
  'Merchandise',
  'Online Courses',
  'Selling Digital Products',
];

// Avatar Specific Options
const avatarTypeOptions = [
  '2D VTuber',
  '3D VTuber',
  'AI Realistic Avatar',
  'Custom Illustrated Cartoon',
  '3D Metahuman',
];

const riggingOptions = [
  'Basic (Audio Only Reactivity)',
  'Advanced (Direct Face Tracking)',
  'Premium (Motion / Full Body Tracking)',
];

const expressionOptions = [
  'Subtle & Professional',
  'Expressive & Dynamic',
  'Highly Animated & Emotive',
];

export default function App() {
  const [mode, setMode] = useState<'standard' | 'avatar'>('standard');
  const [step, setStep] = useState<number>(0);
  const [standardData, setStandardData] = useState<BlueprintData>(initialStandardData);
  const [avatarData, setAvatarData] = useState<AvatarBlueprintData>(initialAvatarData);
  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<string>('overview');
  const [copied, setCopied] = useState<boolean>(false);

  const updateStandardField = (field: keyof BlueprintData, value: any) => {
    setStandardData((prev) => ({ ...prev, [field]: value }));
  };

  const updateAvatarField = (field: keyof AvatarBlueprintData, value: any) => {
    setAvatarData((prev) => ({ ...prev, [field]: value }));
  };

  const toggleStandardMonetization = (item: string) => {
    setStandardData((prev) => {
      const exists = prev.monetization.includes(item);
      const updated = exists
        ? prev.monetization.filter((m) => m !== item)
        : [...prev.monetization, item];
      return { ...prev, monetization: updated.length ? updated : ['YouTube AdSense'] };
    });
  };

  const toggleAvatarMonetization = (item: string) => {
    setAvatarData((prev) => {
      const exists = prev.monetization.includes(item);
      const updated = exists
        ? prev.monetization.filter((m) => m !== item)
        : [...prev.monetization, item];
      return { ...prev, monetization: updated.length ? updated : ['YouTube AdSense'] };
    });
  };

  const maxSteps = mode === 'standard' ? 6 : 7;

  const handleNext = () => {
    if (step < maxSteps) {
      setStep((prev) => prev + 1);
    } else {
      triggerGeneration();
    }
  };

  const handleBack = () => {
    if (step > 0) setStep((prev) => prev - 1);
  };

  const triggerGeneration = () => {
    setIsGenerating(true);
    setTimeout(() => {
      setIsGenerating(false);
      setStep(8); // Render Dashboard
      confetti({
        particleCount: 120,
        spread: 80,
        origin: { y: 0.6 },
      });
    }, 2200);
  };

  const handleCopyPrompt = () => {
    const fullPrompt = mode === 'standard' ? generateFullPrompt(standardData) : generateAvatarFullPrompt(avatarData);
    navigator.clipboard.writeText(fullPrompt);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const restartQuiz = () => {
    setStandardData(initialStandardData);
    setAvatarData(initialAvatarData);
    setStep(0);
    setActiveTab('overview');
  };

  // Precomputing Output for UI
  const standardNames = generateNameSuggestions(standardData.niche, standardData.focus);
  const avatarNames = generateAvatarNames(avatarData.niche, avatarData.focus, avatarData.avatarType);

  const stdTech = generateTechnicalStack(standardData.experience);
  const avTech = generateAvatarToolStack(avatarData.experience, avatarData.avatarType);

  const stdCal = generateContentCalendar(standardData.frequency);
  const avCal = generateAvatarCalendar(avatarData.frequency);

  const stdScript = generateFirstVideoScript(standardData);
  const avScript = generateAvatarVideoScript(avatarData);

  return (
    <div className="min-h-screen bg-slate-900 text-slate-100 flex flex-col items-center font-sans antialiased">
      
      {/* Top Navigation Header */}
      <nav className="w-full border-b border-slate-800 bg-slate-950/60 backdrop-blur-md px-6 py-4 flex items-center justify-between sticky top-0 z-50">
        <div className="flex items-center gap-2 cursor-pointer" onClick={restartQuiz}>
          <div className="bg-red-600 p-2 rounded-xl text-white shadow-lg shadow-red-900/30">
            <svg className="w-6 h-6 fill-current text-white" viewBox="0 0 24 24">
              <path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/>
            </svg>
          </div>
          <span className="font-bold text-xl tracking-tight text-white flex items-center gap-2">
            Faceless<span className="text-red-500">Tube</span> Blueprint
            {step === 8 && (
              <span className="text-xs font-semibold px-2.5 py-0.5 rounded bg-slate-800 border border-slate-700 text-slate-300">
                {mode === 'standard' ? 'Standard' : 'Avatar Edition'}
              </span>
            )}
          </span>
        </div>
        {step > 0 && step < 8 && (
          <div className="text-sm font-medium text-slate-400 bg-slate-800/40 px-3 py-1 rounded-full border border-slate-700/50">
            Step {step} of {maxSteps}
          </div>
        )}
      </nav>

      <main className="flex-1 w-full max-w-6xl p-6 flex flex-col justify-center items-center">

        {/* STEP 0: Selection Welcome */}
        {step === 0 && (
          <div className="max-w-4xl text-center space-y-8 animate-fade-in py-8">
            <div className="inline-flex p-4 rounded-3xl bg-red-500/10 text-red-400 ring-1 ring-red-500/20 shadow-inner">
              <Sparkles className="w-12 h-12 animate-pulse" />
            </div>
            <div className="space-y-4">
              <h1 className="text-4xl md:text-6xl font-extrabold tracking-tight text-white leading-tight">
                Design Your Ultimate <span className="text-transparent bg-clip-text bg-gradient-to-r from-red-400 to-orange-400">Faceless Presence</span>
              </h1>
              <p className="text-slate-400 text-lg md:text-xl max-w-2xl mx-auto">
                Choose the best strategy archetype for your project. Either create direct screen & B-roll voiceovers, or pilot a virtual character persona.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-8 max-w-3xl mx-auto">
              <button
                onClick={() => { setMode('standard'); handleNext(); }}
                className="flex flex-col items-start p-6 rounded-2xl border bg-slate-850 hover:bg-slate-800 border-slate-800 hover:border-slate-700 text-left transition-all hover:scale-[1.02] active:scale-[0.99] group"
              >
                <div className="bg-red-500/10 text-red-400 p-3 rounded-xl border border-red-500/20 group-hover:scale-105 transition-all">
                  <Tv className="w-8 h-8" />
                </div>
                <h3 className="text-xl font-bold text-white mt-4 flex items-center gap-2">
                  Standard Faceless <ArrowRight className="w-4 h-4 opacity-0 group-hover:opacity-100 group-hover:translate-x-1 transition-all" />
                </h3>
                <p className="text-slate-400 text-sm mt-1">
                  High quality script with stock B-roll, motion text, animations, and premium AI voices. Perfect for educational and tech niches.
                </p>
              </button>

              <button
                onClick={() => { setMode('avatar'); handleNext(); }}
                className="flex flex-col items-start p-6 rounded-2xl border bg-slate-850 hover:bg-slate-800 border-slate-800 hover:border-slate-700 text-left transition-all hover:scale-[1.02] active:scale-[0.99] group"
              >
                <div className="bg-red-500/10 text-red-400 p-3 rounded-xl border border-red-500/20 group-hover:scale-105 transition-all">
                  <User className="w-8 h-8" />
                </div>
                <h3 className="text-xl font-bold text-white mt-4 flex items-center gap-2">
                  Avatar & Character <ArrowRight className="w-4 h-4 opacity-0 group-hover:opacity-100 group-hover:translate-x-1 transition-all" />
                </h3>
                <p className="text-slate-400 text-sm mt-1">
                  Piloted 2D/3D VTubers, Cartoon personas, or Realistic AI Talking Heads. Excellent for storytelling, personal brand safety, and news commentary.
                </p>
              </button>
            </div>

            <div className="grid grid-cols-3 gap-4 pt-12 border-t border-slate-800/80 text-slate-400 text-xs md:text-sm max-w-3xl mx-auto">
              <div>
                <div className="font-semibold text-white text-base">3 Minutes</div>
                To Complete
              </div>
              <div>
                <div className="font-semibold text-white text-base">Tailored Strategy</div>
                Custom Blueprint Output
              </div>
              <div>
                <div className="font-semibold text-white text-base">NotebookLM</div>
                Prompts Generator
              </div>
            </div>
          </div>
        )}

        {/* STEP 1: Experience Selection */}
        {step === 1 && (
          <div className="w-full max-w-xl space-y-6 animate-fade-in">
            <div className="space-y-2 text-center">
              <h2 className="text-3xl font-bold text-white">Your Technical Comfort</h2>
              <p className="text-slate-400">What's your current experience with launching a faceless channel?</p>
            </div>
            <div className="grid gap-4 mt-6">
              {experienceOptions.map((opt) => {
                const current = mode === 'standard' ? standardData.experience : avatarData.experience;
                return (
                  <button
                    key={opt}
                    onClick={() => mode === 'standard' ? updateStandardField('experience', opt) : updateAvatarField('experience', opt)}
                    className={`flex items-center justify-between p-5 rounded-2xl border font-medium text-left transition-all ${
                      current === opt
                        ? 'border-red-500 bg-red-500/10 text-white shadow-lg shadow-red-500/10'
                        : 'border-slate-800 bg-slate-850 hover:bg-slate-800 hover:border-slate-700 text-slate-300'
                    }`}
                  >
                    <span className="text-lg">{opt}</span>
                    {current === opt && <CheckCircle className="w-6 h-6 text-red-500" />}
                  </button>
                );
              })}
            </div>
            <div className="flex justify-between mt-8">
              <button onClick={handleBack} className="flex items-center gap-2 text-slate-400 hover:text-white font-medium">
                <ArrowLeft className="w-4 h-4" /> Back
              </button>
              <button onClick={handleNext} className="flex items-center gap-2 bg-slate-100 hover:bg-white text-slate-900 font-semibold px-6 py-3 rounded-xl shadow-md transition-all">
                Next <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* STEP 2: Core Niche & Custom Details */}
        {step === 2 && (
          <div className="w-full max-w-2xl space-y-6 animate-fade-in">
            <div className="space-y-2 text-center">
              <h2 className="text-3xl font-bold text-white">Niche & Focus Market</h2>
              <p className="text-slate-400">Lock down the audience market segment you want to expand into.</p>
            </div>
            <div className="grid gap-6 mt-6">
              <div>
                <label className="block text-sm font-semibold text-slate-300 mb-2">Select Primary Niche</label>
                <select
                  value={mode === 'standard' ? standardData.niche : avatarData.niche}
                  onChange={(e) => mode === 'standard' ? updateStandardField('niche', e.target.value) : updateAvatarField('niche', e.target.value)}
                  className="w-full bg-slate-850 border border-slate-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-red-500 focus:ring-1 focus:ring-red-500"
                >
                  {nicheOptions.map((n) => (
                    <option key={n} value={n}>{n}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-semibold text-slate-300 mb-2">Enter Sub-Niche (Optional)</label>
                <input
                  type="text"
                  placeholder="e.g. VTuber Lore, Stoic Daily Quotes, Luxury Watches"
                  value={mode === 'standard' ? standardData.subNiche : avatarData.subNiche}
                  onChange={(e) => mode === 'standard' ? updateStandardField('subNiche', e.target.value) : updateAvatarField('subNiche', e.target.value)}
                  className="w-full bg-slate-850 border border-slate-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-red-500 focus:ring-1 focus:ring-red-500"
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-slate-300 mb-2">Target Audience Persona</label>
                <input
                  type="text"
                  placeholder="e.g. Remote workers, Introverts, Video editing hobbyists"
                  value={mode === 'standard' ? standardData.targetAudience : avatarData.targetAudience}
                  onChange={(e) => mode === 'standard' ? updateStandardField('targetAudience', e.target.value) : updateAvatarField('targetAudience', e.target.value)}
                  className="w-full bg-slate-850 border border-slate-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-red-500 focus:ring-1 focus:ring-red-500"
                />
              </div>
            </div>
            <div className="flex justify-between mt-8">
              <button onClick={handleBack} className="flex items-center gap-2 text-slate-400 hover:text-white font-medium">
                <ArrowLeft className="w-4 h-4" /> Back
              </button>
              <button onClick={handleNext} className="flex items-center gap-2 bg-slate-100 hover:bg-white text-slate-900 font-semibold px-6 py-3 rounded-xl shadow-md transition-all">
                Next <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* STEP 3: Topic Format & Direct Strategy Focus */}
        {step === 3 && (
          <div className="w-full max-w-2xl space-y-6 animate-fade-in">
            <div className="space-y-2 text-center">
              <h2 className="text-3xl font-bold text-white">Format & Content Angle</h2>
              <p className="text-slate-400">Determine how you narrate and structure your overall presentation.</p>
            </div>
            <div className="grid gap-6 mt-6">
              <div>
                <label className="block text-sm font-semibold text-slate-300 mb-2">Primary Video Topic Format</label>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                  {formatOptions.map((opt) => {
                    const active = mode === 'standard' ? standardData.topicFormat === opt : avatarData.topicFormat === opt;
                    return (
                      <button
                        key={opt}
                        onClick={() => mode === 'standard' ? updateStandardField('topicFormat', opt) : updateAvatarField('topicFormat', opt)}
                        className={`py-2.5 px-3 rounded-lg border text-sm font-medium transition-all ${
                          active
                            ? 'border-red-500 bg-red-500/10 text-white'
                            : 'border-slate-800 bg-slate-850 text-slate-400 hover:text-white'
                        }`}
                      >
                        {opt}
                      </button>
                    );
                  })}
                </div>
              </div>

              <div>
                <label className="block text-sm font-semibold text-slate-300 mb-2">Video Tone Focus</label>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                  {focusOptions.map((opt) => {
                    const active = mode === 'standard' ? standardData.focus === opt : avatarData.focus === opt;
                    return (
                      <button
                        key={opt}
                        onClick={() => mode === 'standard' ? updateStandardField('focus', opt) : updateAvatarField('focus', opt)}
                        className={`py-2.5 px-3 rounded-lg border text-sm font-medium transition-all ${
                          active
                            ? 'border-red-500 bg-red-500/10 text-white'
                            : 'border-slate-800 bg-slate-850 text-slate-400 hover:text-white'
                        }`}
                      >
                        {opt}
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
            <div className="flex justify-between mt-8">
              <button onClick={handleBack} className="flex items-center gap-2 text-slate-400 hover:text-white font-medium">
                <ArrowLeft className="w-4 h-4" /> Back
              </button>
              <button onClick={handleNext} className="flex items-center gap-2 bg-slate-100 hover:bg-white text-slate-900 font-semibold px-6 py-3 rounded-xl shadow-md transition-all">
                Next <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* STEP 4: Video Style & Duration */}
        {step === 4 && (
          <div className="w-full max-w-2xl space-y-6 animate-fade-in">
            <div className="space-y-2 text-center">
              <h2 className="text-3xl font-bold text-white">Production Details</h2>
              <p className="text-slate-400">Plan presentation style and length for viewer engagement.</p>
            </div>
            <div className="grid gap-6 mt-6">
              <div>
                <label className="block text-sm font-semibold text-slate-300 mb-2">Video Aesthetics Style</label>
                <div className="grid grid-cols-2 gap-3">
                  {styleOptions.map((opt) => {
                    const active = mode === 'standard' ? standardData.videoStyle === opt : avatarData.videoStyle === opt;
                    return (
                      <button
                        key={opt}
                        onClick={() => mode === 'standard' ? updateStandardField('videoStyle', opt) : updateAvatarField('videoStyle', opt)}
                        className={`p-3 rounded-xl border text-sm text-left font-medium transition-all ${
                          active
                            ? 'border-red-500 bg-red-500/10 text-white'
                            : 'border-slate-800 bg-slate-850 text-slate-400 hover:text-white'
                        }`}
                      >
                        {opt}
                      </button>
                    );
                  })}
                </div>
              </div>

              <div>
                <label className="block text-sm font-semibold text-slate-300 mb-2">Average Video Length</label>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                  {lengthOptions.map((opt) => {
                    const active = mode === 'standard' ? standardData.videoLength === opt : avatarData.videoLength === opt;
                    return (
                      <button
                        key={opt}
                        onClick={() => mode === 'standard' ? updateStandardField('videoLength', opt) : updateAvatarField('videoLength', opt)}
                        className={`py-2.5 px-3 rounded-lg border text-sm font-medium transition-all ${
                          active
                            ? 'border-red-500 bg-red-500/10 text-white'
                            : 'border-slate-800 bg-slate-850 text-slate-400 hover:text-white'
                        }`}
                      >
                        {opt}
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
            <div className="flex justify-between mt-8">
              <button onClick={handleBack} className="flex items-center gap-2 text-slate-400 hover:text-white font-medium">
                <ArrowLeft className="w-4 h-4" /> Back
              </button>
              <button onClick={handleNext} className="flex items-center gap-2 bg-slate-100 hover:bg-white text-slate-900 font-semibold px-6 py-3 rounded-xl shadow-md transition-all">
                Next <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* STEP 5: Avatar Attributes ONLY IF MODE IS AVATAR */}
        {step === 5 && mode === 'avatar' && (
          <div className="w-full max-w-2xl space-y-6 animate-fade-in">
            <div className="space-y-2 text-center">
              <h2 className="text-3xl font-bold text-white">Your Avatar Persona</h2>
              <p className="text-slate-400">Customize the virtual character you will operate.</p>
            </div>
            <div className="grid gap-6 mt-6">
              <div>
                <label className="block text-sm font-semibold text-slate-300 mb-2">Avatar Archetype</label>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                  {avatarTypeOptions.map((opt) => (
                    <button
                      key={opt}
                      onClick={() => updateAvatarField('avatarType', opt)}
                      className={`py-2 px-3 rounded-lg border text-sm font-medium transition-all ${
                        avatarData.avatarType === opt
                          ? 'border-red-500 bg-red-500/10 text-white'
                          : 'border-slate-800 bg-slate-850 text-slate-400 hover:text-white'
                      }`}
                    >
                      {opt}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-sm font-semibold text-slate-300 mb-2">Rigging & Tracking Method</label>
                <select
                  value={avatarData.riggingLevel}
                  onChange={(e) => updateAvatarField('riggingLevel', e.target.value)}
                  className="w-full bg-slate-850 border border-slate-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-red-500 focus:ring-1 focus:ring-red-500"
                >
                  {riggingOptions.map((rig) => (
                    <option key={rig} value={rig}>{rig}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-semibold text-slate-300 mb-2">Avatar Emotive Expression Level</label>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-2">
                  {expressionOptions.map((opt) => (
                    <button
                      key={opt}
                      onClick={() => updateAvatarField('expressionStyle', opt)}
                      className={`py-2.5 px-3 rounded-lg border text-sm font-medium transition-all ${
                        avatarData.expressionStyle === opt
                          ? 'border-red-500 bg-red-500/10 text-white'
                          : 'border-slate-800 bg-slate-850 text-slate-400 hover:text-white'
                      }`}
                    >
                      {opt}
                    </button>
                  ))}
                </div>
              </div>
            </div>
            <div className="flex justify-between mt-8">
              <button onClick={handleBack} className="flex items-center gap-2 text-slate-400 hover:text-white font-medium">
                <ArrowLeft className="w-4 h-4" /> Back
              </button>
              <button onClick={handleNext} className="flex items-center gap-2 bg-slate-100 hover:bg-white text-slate-900 font-semibold px-6 py-3 rounded-xl shadow-md transition-all">
                Next <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* STEP 5: Name and Publishing Frequency (for Standard), OR STEP 6 Name/Pub for Avatar */}
        {((step === 5 && mode === 'standard') || (step === 6 && mode === 'avatar')) && (
          <div className="w-full max-w-2xl space-y-6 animate-fade-in">
            <div className="space-y-2 text-center">
              <h2 className="text-3xl font-bold text-white">Logistics & Consistency</h2>
              <p className="text-slate-400">Establish name and production cadence to anchor your workflow.</p>
            </div>
            <div className="grid gap-6 mt-6">
              <div>
                <label className="block text-sm font-semibold text-slate-300 mb-2">Do you have a channel name?</label>
                <div className="grid grid-cols-2 gap-3 mb-3">
                  {['Yes, I already have a name', 'No, I need name suggestions'].map((opt) => {
                    const active = mode === 'standard' ? standardData.nameStatus === opt : avatarData.nameStatus === opt;
                    return (
                      <button
                        key={opt}
                        onClick={() => mode === 'standard' ? updateStandardField('nameStatus', opt) : updateAvatarField('nameStatus', opt)}
                        className={`p-3 rounded-xl border text-sm font-medium transition-all ${
                          active
                            ? 'border-red-500 bg-red-500/10 text-white'
                            : 'border-slate-800 bg-slate-850 text-slate-400 hover:text-white'
                        }`}
                      >
                        {opt}
                      </button>
                    );
                  })}
                </div>
                {((mode === 'standard' && standardData.nameStatus.startsWith('Yes')) ||
                  (mode === 'avatar' && avatarData.nameStatus.startsWith('Yes'))) && (
                  <input
                    type="text"
                    placeholder="Enter channel name"
                    value={mode === 'standard' ? standardData.channelName : avatarData.channelName}
                    onChange={(e) => mode === 'standard' ? updateStandardField('channelName', e.target.value) : updateAvatarField('channelName', e.target.value)}
                    className="w-full bg-slate-850 border border-slate-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-red-500 focus:ring-1 focus:ring-red-500"
                  />
                )}
              </div>

              <div>
                <label className="block text-sm font-semibold text-slate-300 mb-2">Production/Upload Cadence</label>
                <select
                  value={mode === 'standard' ? standardData.frequency : avatarData.frequency}
                  onChange={(e) => mode === 'standard' ? updateStandardField('frequency', e.target.value) : updateAvatarField('frequency', e.target.value)}
                  className="w-full bg-slate-850 border border-slate-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-red-500 focus:ring-1 focus:ring-red-500"
                >
                  {frequencyOptions.map((f) => (
                    <option key={f} value={f}>{f}</option>
                  ))}
                </select>
              </div>
            </div>
            <div className="flex justify-between mt-8">
              <button onClick={handleBack} className="flex items-center gap-2 text-slate-400 hover:text-white font-medium">
                <ArrowLeft className="w-4 h-4" /> Back
              </button>
              <button onClick={handleNext} className="flex items-center gap-2 bg-slate-100 hover:bg-white text-slate-900 font-semibold px-6 py-3 rounded-xl shadow-md transition-all">
                Next <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* STEP 6: Monetization (Standard) OR STEP 7: Monetization (Avatar) */}
        {((step === 6 && mode === 'standard') || (step === 7 && mode === 'avatar')) && (
          <div className="w-full max-w-2xl space-y-6 animate-fade-in">
            <div className="space-y-2 text-center">
              <h2 className="text-3xl font-bold text-white">Monetization Goals</h2>
              <p className="text-slate-400">Establish multiple vectors to ensure profit. Select all that apply.</p>
            </div>
            <div className="grid gap-3 mt-6 sm:grid-cols-2">
              {monetizationOptions.map((opt) => {
                const selected = mode === 'standard' ? standardData.monetization.includes(opt) : avatarData.monetization.includes(opt);
                return (
                  <button
                    key={opt}
                    onClick={() => mode === 'standard' ? toggleStandardMonetization(opt) : toggleAvatarMonetization(opt)}
                    className={`flex items-center justify-between p-4 rounded-xl border text-sm font-medium transition-all ${
                      selected
                        ? 'border-red-500 bg-red-500/10 text-white'
                        : 'border-slate-800 bg-slate-850 text-slate-400 hover:bg-slate-800 hover:text-white'
                    }`}
                  >
                    <span>{opt}</span>
                    <span className={`w-5 h-5 rounded-md border flex items-center justify-center transition-all ${
                      selected ? 'bg-red-500 border-red-500 text-white' : 'border-slate-700 bg-slate-900'
                    }`}>
                      {selected && <CheckCircle className="w-4 h-4" />}
                    </span>
                  </button>
                );
              })}
            </div>
            <div className="flex justify-between mt-8">
              <button onClick={handleBack} className="flex items-center gap-2 text-slate-400 hover:text-white font-medium">
                <ArrowLeft className="w-4 h-4" /> Back
              </button>
              <button
                onClick={handleNext}
                className="flex items-center gap-2 bg-gradient-to-r from-red-600 to-orange-600 hover:from-red-500 hover:to-orange-500 text-white font-semibold px-8 py-3 rounded-xl shadow-lg transition-all"
              >
                Assemble Blueprint <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* GENERATING LOAD SCREEN */}
        {isGenerating && (
          <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-md z-50 flex flex-col items-center justify-center space-y-6">
            <div className="relative flex items-center justify-center">
              <RefreshCw className="w-16 h-16 text-red-500 animate-spin" />
              <svg className="w-6 h-6 fill-current text-white absolute animate-pulse" viewBox="0 0 24 24">
                <path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/>
              </svg>
            </div>
            <div className="text-center space-y-2">
              <h3 className="text-2xl font-bold text-white">Forging Strategy Framework...</h3>
              <p className="text-slate-400 max-w-sm">
                Combining {mode === 'avatar' ? 'avatar character presets' : 'cinematic B-roll'} with {mode === 'standard' ? standardData.niche : avatarData.niche} metadata.
              </p>
            </div>
            <div className="w-64 h-2 bg-slate-800 rounded-full overflow-hidden">
              <div className="h-full bg-red-500 animate-loading-bar"></div>
            </div>
          </div>
        )}

        {/* STEP 8: DASHBOARD ACTION ENGINE */}
        {step === 8 && (
          <div className="w-full grid grid-cols-1 md:grid-cols-4 gap-6 animate-fade-in mt-2 items-start">
            
            {/* Action Sidebar */}
            <div className="md:col-span-1 space-y-2">
              <button
                onClick={() => setActiveTab('overview')}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-semibold transition-all ${
                  activeTab === 'overview'
                    ? 'bg-red-500 text-white shadow-lg shadow-red-500/20'
                    : 'bg-slate-850 hover:bg-slate-800 text-slate-400'
                }`}
              >
                <Layout className="w-4 h-4" /> Strategy Overview
              </button>
              <button
                onClick={() => setActiveTab('tools')}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-semibold transition-all ${
                  activeTab === 'tools'
                    ? 'bg-red-500 text-white shadow-lg shadow-red-500/20'
                    : 'bg-slate-850 hover:bg-slate-800 text-slate-400'
                }`}
              >
                <Settings className="w-4 h-4" /> Equipment & Tools
              </button>
              <button
                onClick={() => setActiveTab('calendar')}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-semibold transition-all ${
                  activeTab === 'calendar'
                    ? 'bg-red-500 text-white shadow-lg shadow-red-500/20'
                    : 'bg-slate-850 hover:bg-slate-800 text-slate-400'
                }`}
              >
                <Calendar className="w-4 h-4" /> Content Calendar
              </button>
              <button
                onClick={() => setActiveTab('script')}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-semibold transition-all ${
                  activeTab === 'script'
                    ? 'bg-red-500 text-white shadow-lg shadow-red-500/20'
                    : 'bg-slate-850 hover:bg-slate-800 text-slate-400'
                }`}
              >
                <Video className="w-4 h-4" /> 1st Video Details
              </button>
              <button
                onClick={() => setActiveTab('prompt')}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-semibold transition-all ${
                  activeTab === 'prompt'
                    ? 'bg-red-500 text-white shadow-lg shadow-red-500/20'
                    : 'bg-slate-850 hover:bg-slate-800 text-slate-400'
                }`}
              >
                <Sparkles className="w-4 h-4" /> AI Ready Prompt
              </button>

              <div className="pt-6 border-t border-slate-800">
                <button
                  onClick={restartQuiz}
                  className="w-full flex items-center justify-center gap-2 text-sm font-medium text-slate-400 hover:text-white bg-slate-850/40 hover:bg-slate-850 p-3 rounded-xl border border-slate-800 transition-all"
                >
                  <RefreshCw className="w-4 h-4" /> Redo Session
                </button>
              </div>
            </div>

            {/* Dashboard Display Content */}
            <div className="md:col-span-3 bg-slate-850/60 backdrop-blur-md rounded-2xl border border-slate-800 p-6 md:p-8 min-h-[420px]">
              
              {/* TAB: Overview */}
              {activeTab === 'overview' && (
                <div className="space-y-6">
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
                    <div>
                      <span className="text-xs font-bold uppercase tracking-wider text-red-400 bg-red-500/10 px-2.5 py-1 rounded-md">
                        {mode === 'standard' ? standardData.niche : avatarData.niche}
                      </span>
                      <h3 className="text-3xl font-extrabold text-white mt-2">
                        {mode === 'standard' 
                          ? (standardData.channelName || (standardNames[0] + ' (Suggested)'))
                          : (avatarData.channelName || (avatarNames[0] + ' (Suggested)'))}
                      </h3>
                    </div>
                    <button
                      onClick={() => setActiveTab('prompt')}
                      className="flex items-center gap-2 bg-slate-800 hover:bg-slate-700 text-slate-100 text-sm font-medium px-4 py-2 rounded-xl border border-slate-700 transition-all"
                    >
                      Prompt to NotebookLM
                    </button>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 flex items-center gap-3">
                      <Target className="w-6 h-6 text-red-400 flex-shrink-0" />
                      <div>
                        <p className="text-xs text-slate-500">Target Segment</p>
                        <p className="text-sm font-semibold text-white truncate max-w-[150px]">
                          {(mode === 'standard' ? standardData.targetAudience : avatarData.targetAudience) || 'General Enthusiasts'}
                        </p>
                      </div>
                    </div>
                    <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 flex items-center gap-3">
                      <Clock className="w-6 h-6 text-red-400 flex-shrink-0" />
                      <div>
                        <p className="text-xs text-slate-500">Video Duration</p>
                        <p className="text-sm font-semibold text-white">
                          {mode === 'standard' ? standardData.videoLength : avatarData.videoLength}
                        </p>
                      </div>
                    </div>
                    <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 flex items-center gap-3">
                      <DollarSign className="w-6 h-6 text-red-400 flex-shrink-0" />
                      <div>
                        <p className="text-xs text-slate-500">First Goal Monetization</p>
                        <p className="text-sm font-semibold text-white">
                          {mode === 'standard' ? standardData.monetization[0] : avatarData.monetization[0]}
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* Avatar specifics overview */}
                  {mode === 'avatar' && (
                    <div className="p-4 rounded-xl bg-slate-900/40 border border-slate-800/80 grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <span className="text-xs text-slate-500 font-medium">Avatar Persona Type</span>
                        <p className="text-sm font-bold text-red-400">{avatarData.avatarType}</p>
                      </div>
                      <div>
                        <span className="text-xs text-slate-500 font-medium">Avatar Animation Tracking</span>
                        <p className="text-sm font-bold text-red-400">{avatarData.riggingLevel}</p>
                      </div>
                    </div>
                  )}

                  <div className="space-y-2 mt-4">
                    <h4 className="text-base font-semibold text-slate-200 flex items-center gap-2">
                      <Award className="w-4 h-4 text-red-400" /> Dynamic Name Ideas
                    </h4>
                    <div className="flex flex-wrap gap-2">
                      {(mode === 'standard' ? standardNames : avatarNames).map((name) => (
                        <span key={name} className="px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-sm text-slate-300 font-medium">
                          {name}
                        </span>
                      ))}
                    </div>
                  </div>

                  <div className="space-y-3 mt-4">
                    <h4 className="text-base font-semibold text-slate-200">Execution Directives</h4>
                    <p className="text-slate-400 leading-relaxed text-sm">
                      Launching this {mode === 'avatar' ? `customized character persona utilizing a ${avatarData.avatarType} build` : 'standard B-roll faceless setup'} helps build high audience retention. By creating focused videos tailored to <strong>{mode === 'standard' ? standardData.focus : avatarData.focus}</strong> viewer types, you'll optimize organic metrics. Keep a strict <strong>{mode === 'standard' ? standardData.frequency : avatarData.frequency}</strong> cadence for algorithm signals.
                    </p>
                  </div>
                </div>
              )}

              {/* TAB: Tool Stack */}
              {activeTab === 'tools' && (
                <div className="space-y-6">
                  <div>
                    <h3 className="text-2xl font-bold text-white mb-1">Production Automation Stack</h3>
                    <p className="text-slate-400 text-sm">
                      Best software equipment mapped to: <span className="text-red-400 font-bold">{mode === 'standard' ? standardData.experience : avatarData.experience}</span> level.
                    </p>
                  </div>

                  <div className="grid gap-4 mt-4">
                    {mode === 'standard' && Object.entries(stdTech).map(([category, details]) => (
                      <div key={category} className="p-4 rounded-xl bg-slate-900 border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                        <div className="space-y-1">
                          <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
                            {category === 'script' ? 'AI Scriptwriting' :
                             category === 'voice' ? 'AI Voiceover' :
                             category === 'visuals' ? 'Graphics & B-Roll' :
                             category === 'editing' ? 'Video Editing' : 'Thumbnails'}
                          </span>
                          <h4 className="text-lg font-bold text-white">{details.name}</h4>
                          <p className="text-sm text-slate-400">{details.use}</p>
                        </div>
                      </div>
                    ))}

                    {mode === 'avatar' && Object.entries(avTech).map(([category, details]) => (
                      <div key={category} className="p-4 rounded-xl bg-slate-900 border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                        <div className="space-y-1">
                          <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
                            {category === 'creation' ? 'Avatar Creation' :
                             category === 'tracking' ? 'Tracking & Motion' :
                             category === 'recording' ? 'Livestream/Video Capture' : 'Video Stitching & Editing'}
                          </span>
                          <h4 className="text-lg font-bold text-white">{details.name}</h4>
                          <p className="text-sm text-slate-400">{details.use}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* TAB: Calendar */}
              {activeTab === 'calendar' && (
                <div className="space-y-6">
                  <div>
                    <h3 className="text-2xl font-bold text-white mb-1">Content Creation Pipeline</h3>
                    <p className="text-slate-400 text-sm">
                      Workflow mapping for publishing <strong>{mode === 'standard' ? standardData.frequency : avatarData.frequency}</strong>.
                    </p>
                  </div>

                  <div className="relative border-l-2 border-red-500/30 pl-6 ml-4 space-y-6 mt-4">
                    {(mode === 'standard' ? stdCal : avCal).map((stepDesc, idx) => (
                      <div key={idx} className="relative">
                        <div className="absolute -left-[33px] bg-red-600 rounded-full h-5 w-5 flex items-center justify-center text-xs font-bold text-white border-4 border-slate-900 shadow">
                          {idx + 1}
                        </div>
                        <p className="text-slate-200 text-base font-semibold">{stepDesc}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* TAB: Script */}
              {activeTab === 'script' && (
                <div className="space-y-6">
                  <div className="pb-4 border-b border-slate-800">
                    <h3 className="text-2xl font-bold text-white mb-1">First Video Blueprint</h3>
                    <p className="text-sm text-slate-400">Step-by-step narration breakdown.</p>
                  </div>

                  <div className="space-y-4 text-sm mt-4">
                    <div>
                      <span className="text-xs font-bold text-slate-500 uppercase">Video Title Idea</span>
                      <p className="text-lg font-extrabold text-red-400 mt-1">"{(mode === 'standard' ? stdScript : avScript).title}"</p>
                    </div>

                    {mode === 'avatar' && (
                      <div className="p-3 bg-red-500/10 border border-red-500/20 rounded-xl">
                        <span className="font-bold text-slate-200 text-xs uppercase flex items-center gap-1">
                          <User className="w-3 h-3 text-red-400" /> Avatar Motion Rigging
                        </span>
                        <p className="text-slate-300 mt-1">{(avScript as any).rig}</p>
                      </div>
                    )}

                    <div className="p-3 bg-slate-900/60 rounded-xl border border-slate-800">
                      <span className="font-bold text-slate-200 text-xs uppercase flex items-center gap-1">
                        <Tv className="w-3 h-3 text-red-400" /> Engaging Hook
                      </span>
                      <p className="text-slate-400 mt-1">{(mode === 'standard' ? stdScript : avScript).hook}</p>
                    </div>

                    <div className="p-3 bg-slate-900/60 rounded-xl border border-slate-800">
                      <span className="font-bold text-slate-200 text-xs uppercase flex items-center gap-1">
                        <Tv className="w-3 h-3 text-red-400" /> The Welcome & Story Setting
                      </span>
                      <p className="text-slate-400 mt-1">{(mode === 'standard' ? stdScript : avScript).intro}</p>
                    </div>

                    <div className="p-3 bg-slate-900/60 rounded-xl border border-slate-800">
                      <span className="font-bold text-slate-200 text-xs uppercase flex items-center gap-1 mb-2">
                        <Tv className="w-3 h-3 text-red-400" /> Main Discussion Points
                      </span>
                      <ul className="space-y-2 list-disc list-inside text-slate-400 pl-1">
                        {(mode === 'standard' ? stdScript : avScript).body.map((pt, idx) => (
                          <li key={idx}>{pt}</li>
                        ))}
                      </ul>
                    </div>

                    <div className="p-3 bg-slate-900/60 rounded-xl border border-slate-800">
                      <span className="font-bold text-slate-200 text-xs uppercase flex items-center gap-1">
                        <Tv className="w-3 h-3 text-red-400" /> Video Ending Strategy
                      </span>
                      <p className="text-slate-400 mt-1">{(mode === 'standard' ? stdScript : avScript).cta}</p>
                    </div>

                    <div>
                      <span className="text-xs font-bold text-slate-500 uppercase">Visual Thumbnail Archetype</span>
                      <p className="text-slate-300 mt-1 italic">"{(mode === 'standard' ? stdScript : avScript).thumbnailDesc}"</p>
                    </div>
                  </div>
                </div>
              )}

              {/* TAB: NotebookLM Ready Prompt */}
              {activeTab === 'prompt' && (
                <div className="space-y-6">
                  <div>
                    <h3 className="text-2xl font-bold text-white mb-1">Interactive Strategy Prompt</h3>
                    <p className="text-slate-400 text-sm">Copy and load exact blueprint payload to build a script using AI tools.</p>
                  </div>

                  <div className="bg-slate-950 p-4 border border-slate-800 rounded-xl relative">
                    <pre className="text-slate-300 text-xs md:text-sm font-mono whitespace-pre-wrap leading-relaxed max-h-[300px] overflow-y-auto pr-8">
                      {mode === 'standard' ? generateFullPrompt(standardData) : generateAvatarFullPrompt(avatarData)}
                    </pre>
                  </div>

                  <div className="space-y-4">
                    <div className="bg-slate-900 rounded-xl p-4 border border-slate-800 space-y-2 text-sm text-slate-400">
                      <h4 className="text-white font-bold text-base">Execution Steps:</h4>
                      <ol className="list-decimal pl-4 space-y-1">
                        <li>Click <span className="font-bold text-white">"Copy Full Prompt"</span> below.</li>
                        <li>Load a clean chat/source box in <span className="text-white">NotebookLM</span> or <span className="text-white">ChatGPT</span>.</li>
                        <li>Paste your fully structured prompt and execute!</li>
                      </ol>
                    </div>

                    <button
                      onClick={handleCopyPrompt}
                      className="w-full flex items-center justify-center gap-2 bg-red-600 hover:bg-red-500 text-white font-semibold py-4 rounded-xl shadow-lg transition-all transform hover:-translate-y-0.5 active:translate-y-0"
                    >
                      {copied ? <CheckCircle className="w-5 h-5" /> : <Copy className="w-5 h-5" />}
                      {copied ? 'Successfully Copied!' : 'Copy Full Prompt'}
                    </button>
                  </div>
                </div>
              )}

            </div>
          </div>
        )}

      </main>

      <footer className="w-full text-center py-4 text-xs text-slate-600 border-t border-slate-800 mt-8">
        Faceless YouTube Channel Blueprint Creator. All generation tailored dynamically.
      </footer>
    </div>
  );
}
