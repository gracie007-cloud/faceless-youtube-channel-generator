export interface BlueprintData {
  experience: string;
  niche: string;
  subNiche: string;
  targetAudience: string;
  topicFormat: string;
  nameStatus: string;
  channelName: string;
  monetization: string[];
  frequency: string;
  focus: string;
  videoStyle: string;
  videoLength: string;
}

export function generateNameSuggestions(niche: string, focus: string): string[] {
  const nicheWords: Record<string, string[]> = {
    'Autos & Vehicles': ['Gear', 'Auto', 'Rev', 'Drive', 'Motors', 'Wheel'],
    'Comedy': ['Laugh', 'Giggle', 'Fun', 'Humor', 'Joke', 'Chuckles'],
    'Education': ['Mind', 'Brain', 'Academy', 'Learn', 'Class', 'School'],
    'Entertainment': ['Vibe', 'Buzz', 'Zone', 'Flicks', 'Show', 'Hub'],
    'Film & Animation': ['Frame', 'Pixel', 'Toon', 'Cinema', 'Reel', 'Cut'],
    'Gaming': ['Quest', 'Loot', 'Level', 'Play', 'Game', 'Pixel'],
    'How-to & Style': ['Craft', 'Style', 'Guide', 'Skill', 'How', 'Studio'],
    'Music': ['Beat', 'Melody', 'Tune', 'Rhythm', 'Sonic', 'Audio'],
    'News & Politics': ['Report', 'Pulse', 'Feed', 'Daily', 'Press', 'Wire'],
    'Nonprofits & Activism': ['Hope', 'Action', 'Voice', 'Impact', 'Cause', 'Change'],
    'People & Blogs': ['Life', 'Diary', 'Story', 'Path', 'Tale', 'Soul'],
    'Pets & Animals': ['Paw', 'Fur', 'Critter', 'Wild', 'Tail', 'Zoo'],
    'Science & Technology': ['Tech', 'Lab', 'Future', 'Quantum', 'Cyber', 'Atom'],
    'Sports': ['Fit', 'Pro', 'Track', 'Field', 'Game', 'Athletic'],
    'Travel & Events': ['Wander', 'Globe', 'Compass', 'Trek', 'Voyage', 'Jet'],
  };

  const focusWords: Record<string, string[]> = {
    'Analysis': ['Insights', 'Analytics', 'Review', 'Lab'],
    'Beginner-Friendly': ['Basics', '101', 'Simplified', 'Starter'],
    'Deep Dives': ['Uncovered', 'Deep Dive', 'Explained', 'Lore'],
    'Psychology and Sentiments': ['Mind', 'Psyche', 'Secrets', 'Behavior'],
    'Recap & Quick Briefs': ['Brief', 'Recap', 'Express', 'Flash'],
    'Report Summaries': ['Digest', 'Reports', 'Briefing', 'Notes'],
    'Sector/Industry Updates': ['Watch', 'Updates', 'Pulse', 'Hub'],
    'Spotlights': ['Showcase', 'Spotlight', 'Features', 'Stars'],
    'Strategies': ['Tactics', 'Blueprint', 'Mastery', 'Guide'],
    'Trends': ['Now', 'Buzz', 'Trends', 'Viral'],
  };

  const defaults = ['Channel', 'HQ', 'Network', 'Central', 'Studio', 'Media'];

  const nList = nicheWords[niche] || defaults;
  const fList = focusWords[focus] || defaults;

  const suggestions: string[] = [];
  for (let i = 0; i < 5; i++) {
    const nw = nList[Math.floor(Math.random() * nList.length)];
    const fw = fList[Math.floor(Math.random() * fList.length)];
    const dw = defaults[Math.floor(Math.random() * defaults.length)];

    const combo = Math.random() > 0.5 ? `${fw} ${nw}` : `${nw} ${fw}`;
    const choice = Math.random() > 0.5 ? combo : `${nw} ${dw}`;

    if (!suggestions.includes(choice)) {
      suggestions.push(choice);
    } else {
      suggestions.push(`${nw} ${fw} ${dw}`);
    }
  }

  return Array.from(new Set(suggestions)).slice(0, 5);
}

export function generateTechnicalStack(experience: string) {
  if (experience === 'Advanced') {
    return {
      script: { name: 'Claude 3.5 Sonnet & ChatGPT Plus', use: 'High-level script structuring, storytelling, and nuanced hooks.' },
      voice: { name: 'ElevenLabs (Voice Cloning/Custom Voice)', use: 'Realistic AI voice generation with emotional pacing.' },
      visuals: { name: 'Midjourney v6, Runway Gen-2, Pexels Premium', use: 'High-fidelity cinematic visual generation and stylized B-roll.' },
      editing: { name: 'Premiere Pro & After Effects', use: 'Multi-layer complex motion graphics, overlays, and color grading.' },
      thumbnail: { name: 'Adobe Photoshop + Canva Pro', use: 'Clickbait masks, custom typography, and multi-layered compositions.' }
    };
  } else if (experience === 'Intermediate') {
    return {
      script: { name: 'ChatGPT 4o & Claude Instant', use: 'Prompt-engineered video scripts with audience engagement points.' },
      voice: { name: 'ElevenLabs Standard / Murf AI', use: 'High-quality natural voices for direct audio rendering.' },
      visuals: { name: 'Leonardo AI & Pixabay / Pexels', use: 'Generating niche graphics and finding relevant free stock B-roll.' },
      editing: { name: 'CapCut Desktop / DaVinci Resolve', use: 'Rich transitions, dynamic captions, and modern effects with speed.' },
      thumbnail: { name: 'Canva Pro + Remove.bg', use: 'Easy templates, outline effects, and modern click-worthy layouts.' }
    };
  } else {
    return {
      script: { name: 'ChatGPT (Free)', use: 'Generating topic ideas and basic structured bullet points for scripts.' },
      voice: { name: 'Speechify / ElevenLabs (Free tier)', use: 'Clean basic voice synthesis for standard readouts.' },
      visuals: { name: 'Pexels & Canva Free Assets', use: 'Free stock videos and standard visual combinations.' },
      editing: { name: 'CapCut Mobile / Desktop', use: 'Simplest auto-captions, basic cuts, and built-in transitions.' },
      thumbnail: { name: 'Canva Free Tier', use: 'Pre-made YouTube thumbnail templates and standard sticker layouts.' }
    };
  }
}

export function generateContentCalendar(frequency: string) {
  const schedules: Record<string, string[]> = {
    'Daily': ['Day 1: Script + Audio', 'Day 2: Edit + Upload', 'Day 3: Script + Audio', 'Day 4: Edit + Upload'],
    '1-2 times per week': ['Monday: Content Research', 'Tuesday: Scriptwriting', 'Wednesday: Audio Recording', 'Thursday: Video Editing', 'Friday: Thumbnail + SEO', 'Saturday: Upload (10:00 AM)', 'Sunday: Rest & Analytics'],
    '3-5 times per week': ['Mon/Wed/Fri: Upload Days', 'Tue/Thu: Batch Scripting & Recording', 'Sat/Sun: Editing marathons'],
    'Bi-weekly': ['Week 1: Deep Research + Full Script + Audio', 'Week 2: Intensive Video Editing + SEO Prep + Upload'],
    'Monthly': ['Week 1: Brainstorm & Scripting', 'Week 2: Asset Collection & Voice', 'Week 3: Deep Editing', 'Week 4: SEO + Launch + Promotion']
  };

  return schedules[frequency] || schedules['1-2 times per week'];
}

export function generateFirstVideoScript(data: BlueprintData) {
  const { niche, subNiche, videoStyle, focus, topicFormat } = data;
  const topicName = subNiche || niche;

  return {
    title: `${topicName} Uncovered: The Secret Everyone is Missing`,
    hook: `0:00 - 0:15 | Ask a heavy question about ${topicName}. Use sudden B-roll shifts every 2 seconds to boost initial retention.`,
    intro: `0:15 - 1:00 | Introduce the concept of ${topicFormat}. Create curiosity by teasing a big reveal that happens later in the video.`,
    body: [
      `Point 1: The current landscape of ${topicName} and why it's changing fast.`,
      `Point 2: A ${focus}-driven breakdown of the biggest problem in this space.`,
      `Point 3: How to apply this as a ${videoStyle} strategy effectively.`,
      `Point 4: Step-by-step optimization based on standard ${niche} methods.`
    ],
    cta: `Wrap-up | Ask the audience to comment their thoughts on ${topicName}. Pitch subscription to get more ${focus} content.`,
    thumbnailDesc: `Bold text stating "DON'T IGNORE THIS". A high-contrast split-screen image showing before vs after, or a glowing focal point representing ${topicName}.`
  };
}

export function generateFullPrompt(data: BlueprintData): string {
  return `You are an interactive AI Coach designed to guide me through the launch of my Faceless YouTube Channel.
Here is my custom channel criteria:
- Experience Level: ${data.experience}
- Niche: ${data.niche}
- Sub-Niche: ${data.subNiche || 'General'}
- Target Audience: ${data.targetAudience}
- Content Format/Topic: ${data.topicFormat}
- Channel Name: ${data.channelName || 'Needs suggestions'}
- Chosen Monetization: ${data.monetization.join(', ')}
- Upload Frequency: ${data.frequency}
- Focus Area: ${data.focus}
- Video Style: ${data.videoStyle}
- Desired Video Length: ${data.videoLength}

Based on these details, please formulate an extensive roadmap:
1. Define a powerful visual identity (color palette, logo archetype).
2. Generate 5 title ideas and a thorough script outline for my first video.
3. Recommend best practices for automated SEO and ranking in search.
4. Give an evaluation of milestones to reach my chosen monetization criteria.

Acknowledge these parameters and let us begin step-by-step.`;
}
