export interface AvatarBlueprintData {
  experience: string;
  niche: string;
  subNiche: string;
  targetAudience: string;
  topicFormat: string;
  nameStatus: string;
  channelName: string;
  monetization: string[];
  frequency: string;
  focus: string;
  videoStyle: string;
  videoLength: string;
  // Avatar specifics
  avatarType: string;
  riggingLevel: string;
  expressionStyle: string;
}

export function generateNameSuggestions(niche: string, focus: string, avatarType: string): string[] {
  const nicheWords: Record<string, string[]> = {
    'Autos & Vehicles': ['Gear', 'Auto', 'Rev', 'Drive', 'Motors', 'Wheel'],
    'Comedy': ['Laugh', 'Giggle', 'Fun', 'Humor', 'Joke', 'Chuckles'],
    'Education': ['Mind', 'Brain', 'Academy', 'Learn', 'Class', 'School'],
    'Entertainment': ['Vibe', 'Buzz', 'Zone', 'Flicks', 'Show', 'Hub'],
    'Film & Animation': ['Frame', 'Pixel', 'Toon', 'Cinema', 'Reel', 'Cut'],
    'Gaming': ['Quest', 'Loot', 'Level', 'Play', 'Game', 'Pixel'],
    'How-to & Style': ['Craft', 'Style', 'Guide', 'Skill', 'How', 'Studio'],
    'Music': ['Beat', 'Melody', 'Tune', 'Rhythm', 'Sonic', 'Audio'],
    'News & Politics': ['Report', 'Pulse', 'Feed', 'Daily', 'Press', 'Wire'],
    'Nonprofits & Activism': ['Hope', 'Action', 'Voice', 'Impact', 'Cause', 'Change'],
    'People & Blogs': ['Life', 'Diary', 'Story', 'Path', 'Tale', 'Soul'],
    'Pets & Animals': ['Paw', 'Fur', 'Critter', 'Wild', 'Tail', 'Zoo'],
    'Science & Technology': ['Tech', 'Lab', 'Future', 'Quantum', 'Cyber', 'Atom'],
    'Sports': ['Fit', 'Pro', 'Track', 'Field', 'Game', 'Athletic'],
    'Travel & Events': ['Wander', 'Globe', 'Compass', 'Trek', 'Voyage', 'Jet'],
  };

  const focusWords: Record<string, string[]> = {
    'Analysis': ['Insights', 'Analytics', 'Review', 'Lab'],
    'Beginner-Friendly': ['Basics', '101', 'Simplified', 'Starter'],
    'Deep Dives': ['Uncovered', 'Deep Dive', 'Explained', 'Lore'],
    'Psychology and Sentiments': ['Mind', 'Psyche', 'Secrets', 'Behavior'],
    'Recap & Quick Briefs': ['Brief', 'Recap', 'Express', 'Flash'],
    'Report Summaries': ['Digest', 'Reports', 'Briefing', 'Notes'],
    'Sector/Industry Updates': ['Watch', 'Updates', 'Pulse', 'Hub'],
    'Spotlights': ['Showcase', 'Spotlight', 'Features', 'Stars'],
    'Strategies': ['Tactics', 'Blueprint', 'Mastery', 'Guide'],
    'Trends': ['Now', 'Buzz', 'Trends', 'Viral'],
  };

  const avatarSuffixes: Record<string, string[]> = {
    '2D VTuber': ['V2D', 'VT', 'Chibi', 'Live2D', 'Anima'],
    '3D VTuber': ['3D', 'Meta', 'V3D', 'Virtual', 'Poly'],
    'AI Realistic Avatar': ['Host', 'Synthetic', 'Bot', 'Sim', 'AI'],
    'Custom Illustrated Cartoon': ['Toon', 'Drawn', 'Sketch', 'Art', 'Ink'],
    '3D Metahuman': ['Humanoid', 'Prime', 'Unreal', 'Mesh', 'Forge'],
  };

  const defaults = ['Channel', 'HQ', 'Network', 'Central', 'Studio', 'Media'];

  const nList = nicheWords[niche] || defaults;
  const fList = focusWords[focus] || defaults;
  const aList = avatarSuffixes[avatarType] || ['Virtual', 'Avatar'];

  const suggestions: string[] = [];
  for (let i = 0; i < 5; i++) {
    const nw = nList[Math.floor(Math.random() * nList.length)];
    const fw = fList[Math.floor(Math.random() * fList.length)];
    const aw = aList[Math.floor(Math.random() * aList.length)];

    const combo = Math.random() > 0.5 ? `${nw} ${aw}` : `${fw} ${aw}`;
    const choice = Math.random() > 0.3 ? combo : `${nw} ${fw}`;

    if (!suggestions.includes(choice)) {
      suggestions.push(choice);
    } else {
      suggestions.push(`${nw} ${aw} Studio`);
    }
  }

  return Array.from(new Set(suggestions)).slice(0, 5);
}

export function generateAvatarToolStack(experience: string, avatarType: string) {
  let creationTool = 'Canva & VRoid Studio (Free)';
  let trackingTool = 'VSeeFace / Webcam';
  let renderingTool = 'OBS Studio';

  if (avatarType.includes('2D VTuber')) {
    creationTool = experience === 'Advanced' ? 'Live2D Cubism & Photoshop' : 'Vroid Studio / ReadyPlayerMe';
    trackingTool = experience === 'Advanced' ? 'VTube Studio + iPhone FaceID' : 'OBS Studio + Webcam';
  } else if (avatarType.includes('AI Realistic Avatar')) {
    creationTool = experience === 'Advanced' ? 'Synthesia / HeyGen' : 'SadTalker / D-ID Free';
    trackingTool = 'None (Audio Driven Lipsync)';
    renderingTool = 'CapCut Desktop / Premiere';
  } else if (avatarType.includes('3D Metahuman')) {
    creationTool = 'Unreal Engine 5 Metahuman Creator';
    trackingTool = experience === 'Advanced' ? 'Live Link Face & Rokoko' : 'Audio2Face';
    renderingTool = 'Unreal Engine / OBS';
  }

  return {
    creation: { name: creationTool, use: 'Building & customizing the visual persona.' },
    tracking: { name: trackingTool, use: 'Real-time or post-production motion capture & audio tracking.' },
    recording: { name: renderingTool, use: 'Capturing live performance alongside screen/presentations.' },
    editing: {
      name: experience === 'Advanced' ? 'Adobe After Effects & Premiere' : 'CapCut Desktop',
      use: 'Adding high-retention effects, multi-camera cuts, and sound overlays.'
    }
  };
}

export function generateFirstVideoScript(data: AvatarBlueprintData) {
  const { niche, subNiche, videoStyle, focus, avatarType, riggingLevel } = data;
  const topicName = subNiche || niche;

  return {
    title: `The Ultimate Truth About ${topicName} [Revealed by ${avatarType}]`,
    rig: riggingLevel,
    hook: `0:00 - 0:15 | Avatar appears with a shocked expression/rigging pose. Use an intense opening question to maximize hook metrics.`,
    intro: `0:15 - 1:00 | Briefly welcome viewers. The avatar uses high hand/eye movement tracking to indicate dynamic energy. State what to expect.`,
    body: [
      `1. Deep Dive on ${topicName} trends with matching background slide visualizer.`,
      `2. Break down standard ${focus} concerns while testing avatar responsiveness.`,
      `3. Deliver a specific, punchy ${videoStyle} solution.`,
      `4. Walk through visual or technical ${niche} hacks step by step.`
    ],
    cta: `Ending | Prompt viewers to subscribe to the ${avatarType}-led channel for more regular insights on ${niche}. Have the avatar wave.`,
    thumbnailDesc: `Vibrant background, high contrast, close-up shot of the avatar's custom face looking surprised next to glowing text about ${topicName}.`
  };
}

export function generateContentCalendar(frequency: string) {
  const schedules: Record<string, string[]> = {
    'Daily': ['Day 1: Avatar posing & Scripting', 'Day 2: Motion Capture + Voice recording', 'Day 3: Video stitching + Publishing'],
    '1-2 times per week': ['Monday: Content ideation & scripting', 'Tuesday: Avatar performance capture', 'Wednesday: Video editing + asset insertion', 'Thursday: SEO setup & publishing'],
    '3-5 times per week': ['Batch 1 (Tue): Shoot 2 video sessions', 'Batch 2 (Thu): Direct multi-cam edits', 'Weekend: Trend monitoring'],
    'Bi-weekly': ['Week 1: High fidelity visual prep + Complete scripting', 'Week 2: Full motion capture recording & custom sound syncing'],
    'Monthly': ['Weeks 1-2: Epic storyboard + customized avatar scenes', 'Weeks 3-4: Post processing + SEO prep + Release']
  };

  return schedules[frequency] || schedules['1-2 times per week'];
}

export function generateFullPrompt(data: AvatarBlueprintData): string {
  return `You are an interactive AI Coach tailored for launching an Avatar-Led, Faceless YouTube Channel.
Here is my channel blueprint parameters:
- Experience Level: ${data.experience}
- Niche: ${data.niche}
- Sub-Niche: ${data.subNiche || 'General'}
- Target Audience: ${data.targetAudience}
- Content Format/Topic: ${data.topicFormat}
- Channel Name: ${data.channelName || 'Needs suggestions'}
- Chosen Monetization: ${data.monetization.join(', ')}
- Upload Frequency: ${data.frequency}
- Focus Area: ${data.focus}
- Video Style: ${data.videoStyle}
- Desired Video Length: ${data.videoLength}
- Avatar Concept: ${data.avatarType}
- Avatar Rigging Style: ${data.riggingLevel}
- Expression/Emote Style: ${data.expressionStyle}

Please deliver a customized roadmap for my Avatar-led channel:
1. Suggest 5 specific visual brand aesthetics (color hex codes, backdrop lighting styles).
2. Generate 5 unique title concepts and a targeted script with specific pose & expression cue markers for my avatar.
3. Recommend best SEO practices for metadata, plus tag ideas.
4. Give a full analysis of milestone rewards and step-by-step monetization tactics.

Acknowledge these parameters and formulate the output step-by-step.`;
}
