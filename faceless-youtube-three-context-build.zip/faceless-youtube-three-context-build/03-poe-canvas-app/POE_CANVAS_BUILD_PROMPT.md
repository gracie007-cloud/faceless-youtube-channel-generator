# Poe Canvas Build Prompt — Canvas App Variant

Create a Poe Canvas app called **Faceless YouTube Blueprint Coach**.

The app should be a focused, single-session wizard for generating a faceless YouTube channel launch plan.

## Canvas scope
Keep the app compact and self-contained. Use the 3-phase flow:
1. Foundation — experience, niche, target audience, channel idea.
2. Content — video style, content focus, video length, upload cadence.
3. Strategy — monetization, channel naming, launch priorities.

## Output behavior
When the user completes the wizard, show:
- A concise summary of their selections.
- A structured prompt block.
- A generated starter channel blueprint panel.
- Buttons: Copy Prompt, Regenerate, Ask Poe Bot.

## Poe-native AI pairing
Pair the Canvas app with a **Poe Script Bot**, not a Prompt Bot, because the workflow should support multi-step formatting and optional model routing.

The Canvas app should be able to send the compiled wizard payload to the Script Bot and stream the answer inline.

## UX constraints
- No external database.
- No custom auth.
- No API keys.
- No global SaaS navigation.
- Chat history can serve as lightweight persistence.
- Prioritize flow, clarity, and immediate output.
