# Canvas App Variant — Poe.com

`index.html` is a single-file Canvas-friendly prototype. Use `POE_CANVAS_BUILD_PROMPT.md` with Poe App Creator if rebuilding natively inside Poe. Use `POE_SCRIPT_BOT_SYSTEM_PROMPT.md` for the paired Poe Script Bot.

Recommended create type pairing: **Poe Script Bot**.
